"""Application configuration using pydantic-settings."""
from __future__ import annotations
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # App
    app_name: str = "World Cup Predictor"
    app_version: str = "1.0.0"
    debug: bool = False

    # Database (SQLite for local dev, PostgreSQL for production)
    database_url: str = "sqlite+aiosqlite:///./worldcup.db"
    database_echo: bool = False

    # Redis (optional — falls back to in-memory if unavailable)
    redis_url: str = "redis://localhost:6379/0"
    cache_ttl_seconds: int = 300  # 5 minutes

    # External APIs
    odds_api_key: str = ""
    odds_api_base_url: str = "https://api.the-odds-api.com/v4"

    # ML Model
    model_path: str = "models/xgboost_worldcup.json"
    monte_carlo_simulations: int = 100_000

    # NLP
    sentiment_model_name: str = "nlptown/bert-base-multilingual-uncased-sentiment"

    # CORS
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:8000"]

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


@lru_cache
def get_settings() -> Settings:
    return Settings()
