"""Tournament and Group entities."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Group:
    """World Cup group (e.g., Group A)."""
    name: str = ""  # "A" through "H"
    team_ids: list[int] = field(default_factory=list)

    @property
    def size(self) -> int:
        return len(self.team_ids)


@dataclass
class Tournament:
    """Represents the World Cup tournament."""
    id: int | None = None
    name: str = "FIFA World Cup 2026"
    year: int = 2026
    host_country: str = "USA/Canada/Mexico"
    groups: list[Group] = field(default_factory=list)
    total_teams: int = 48
    created_at: datetime = field(default_factory=datetime.utcnow)
