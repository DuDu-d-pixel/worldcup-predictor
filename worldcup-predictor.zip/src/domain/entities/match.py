"""Match entity."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum


class MatchType(str, Enum):
    GROUP = "group"
    ROUND_OF_16 = "round_of_16"
    QUARTER_FINAL = "quarter_final"
    SEMI_FINAL = "semi_final"
    THIRD_PLACE = "third_place"
    FINAL = "final"


class MatchResult(str, Enum):
    HOME_WIN = "home_win"
    DRAW = "draw"
    AWAY_WIN = "away_win"


@dataclass
class Match:
    """Represents a single match."""
    id: int | None = None
    home_team_id: int = 0
    away_team_id: int = 0
    home_score: int | None = None
    away_score: int | None = None
    match_date: date = field(default_factory=date.today)
    match_type: MatchType = MatchType.GROUP
    tournament: str = "FIFA World Cup 2026"
    home_xg: float | None = None
    away_xg: float | None = None
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def result(self) -> MatchResult | None:
        if self.home_score is None or self.away_score is None:
            return None
        if self.home_score > self.away_score:
            return MatchResult.HOME_WIN
        elif self.home_score < self.away_score:
            return MatchResult.AWAY_WIN
        return MatchResult.DRAW

    @property
    def is_played(self) -> bool:
        return self.home_score is not None and self.away_score is not None
