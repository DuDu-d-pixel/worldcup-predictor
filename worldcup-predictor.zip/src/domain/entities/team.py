"""Team entity — core domain object."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Team:
    """Represents a national team in the World Cup."""
    id: int | None = None
    name: str = ""
    code: str = ""  # FIFA 3-letter code (e.g., BRA, GER)
    fifa_ranking: int = 0
    elo_rating: float = 1500.0
    squad_market_value: float = 0.0  # in EUR
    group: str = ""  # e.g., "A", "B"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def elo_tier(self) -> str:
        """Classify team strength by Elo rating."""
        if self.elo_rating >= 2000:
            return "elite"
        elif self.elo_rating >= 1800:
            return "strong"
        elif self.elo_rating >= 1600:
            return "average"
        else:
            return "weak"
