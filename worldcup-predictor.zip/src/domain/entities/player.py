"""Player entity."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum


class Position(str, Enum):
    GK = "GK"
    DEF = "DEF"
    MID = "MID"
    FWD = "FWD"


@dataclass
class Player:
    """Represents a player."""
    id: int | None = None
    name: str = ""
    team_id: int = 0
    position: Position = Position.MID
    market_value: float = 0.0  # in EUR
    age: int = 25
    is_injured: bool = False
    injury_type: str | None = None
    expected_return: date | None = None
    recent_appearances: int = 0  # last 10 matches
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def availability_score(self) -> float:
        """0.0 = unavailable, 1.0 = fully available."""
        if not self.is_injured:
            return 1.0
        if self.expected_return and self.expected_return <= date.today():
            return 0.8  # recently recovered, not match-fit
        return 0.0
