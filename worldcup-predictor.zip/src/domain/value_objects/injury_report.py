"""Injury report value object."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class InjuryReport:
    """Aggregated injury status for a team."""
    total_players: int = 0
    injured_players: int = 0
    injured_market_value: float = 0.0  # total market value of injured players
    total_market_value: float = 0.0    # total squad market value
    injury_score: float = 0.0          # 0.0 = healthy, 1.0 = devastated

    @property
    def availability_ratio(self) -> float:
        """Ratio of available squad value."""
        if self.total_market_value == 0:
            return 1.0
        return 1.0 - (self.injured_market_value / self.total_market_value)
