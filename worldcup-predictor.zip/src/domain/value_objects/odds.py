"""Odds value objects."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class OddsSnapshot:
    """Immutable snapshot of betting odds from a single bookmaker."""
    bookmaker: str
    home_win: float
    draw: float
    away_win: float
    timestamp: str  # ISO format

    @property
    def implied_probs(self) -> tuple[float, float, float]:
        """Raw implied probabilities (sum > 1 due to overround)."""
        p_home = 1.0 / self.home_win
        p_draw = 1.0 / self.draw
        p_away = 1.0 / self.away_win
        return (p_home, p_draw, p_away)

    @property
    def overround(self) -> float:
        """Bookmaker's margin."""
        return sum(self.implied_probs) - 1.0

    @property
    def fair_probs(self) -> tuple[float, float, float]:
        """Overround-adjusted probabilities that sum to 1.0."""
        p_h, p_d, p_a = self.implied_probs
        total = p_h + p_d + p_a
        return (p_h / total, p_d / total, p_a / total)


@dataclass(frozen=True)
class OddsMovement:
    """Tracks odds movement from opening to current."""
    opening: OddsSnapshot
    current: OddsSnapshot

    @property
    def home_win_change(self) -> float:
        """Percentage change in home win odds. Negative = odds shortened (more favored)."""
        return (self.current.home_win - self.opening.home_win) / self.opening.home_win

    @property
    def draw_change(self) -> float:
        return (self.current.draw - self.opening.draw) / self.opening.draw

    @property
    def away_win_change(self) -> float:
        return (self.current.away_win - self.opening.away_win) / self.opening.away_win

    @property
    def implied_prob_shift_home(self) -> float:
        """Shift in home implied probability (positive = more favored)."""
        p_open = 1.0 / self.opening.home_win
        p_now = 1.0 / self.current.home_win
        return p_now - p_open
