"""Expected Goals (xG) statistics value object."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class XGStats:
    """Immutable xG statistics for a team over a window of matches."""
    xg_per_match: float = 0.0       # Expected goals scored per match
    xga_per_match: float = 0.0      # Expected goals against per match
    xg_diff: float = 0.0            # xG - xGA
    xg_trend: float = 0.0           # Slope of xG over recent matches (positive = improving)
    matches_sampled: int = 0

    @classmethod
    def from_match_xgs(cls, xgs_for: list[float], xgs_against: list[float]) -> XGStats:
        """Compute XGStats from a list of per-match xG values."""
        import numpy as np
        n = len(xgs_for)
        if n == 0:
            return cls()
        xg_arr = np.array(xgs_for)
        xga_arr = np.array(xgs_against)
        xg_mean = float(np.mean(xg_arr))
        xga_mean = float(np.mean(xga_arr))
        # Linear regression slope for trend
        if n >= 3:
            x = np.arange(n, dtype=float)
            slope = float(np.polyfit(x, xg_arr, 1)[0])
        else:
            slope = 0.0
        return cls(
            xg_per_match=round(xg_mean, 3),
            xga_per_match=round(xga_mean, 3),
            xg_diff=round(xg_mean - xga_mean, 3),
            xg_trend=round(slope, 4),
            matches_sampled=n,
        )
