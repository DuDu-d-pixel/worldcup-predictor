"""Elo rating value object — immutable."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class EloRating:
    """Immutable Elo rating with validation."""
    value: float

    def __post_init__(self) -> None:
        if not 800 <= self.value <= 3000:
            raise ValueError(f"Elo rating must be between 800 and 3000, got {self.value}")

    @classmethod
    def from_fifa_rank(cls, rank: int) -> EloRating:
        """Convert FIFA ranking to approximate Elo rating."""
        # Top rank ~2100 Elo, rank 100 ~1200 Elo
        elo = 2100 - (rank - 1) * 9.0
        elo = max(1200, min(2100, elo))
        return cls(value=round(elo, 1))

    def expected_score(self, opponent: EloRating) -> float:
        """Calculate expected score against an opponent."""
        return 1.0 / (1.0 + 10 ** ((opponent.value - self.value) / 400.0))

    def update(self, actual_score: float, expected_score: float, k_factor: float) -> EloRating:
        """Return new Elo rating after a match."""
        new_value = self.value + k_factor * (actual_score - expected_score)
        return EloRating(value=round(new_value, 1))
