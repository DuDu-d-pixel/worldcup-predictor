"""Repository interfaces (abstract base classes)."""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Sequence
from src.domain.entities.team import Team
from src.domain.entities.match import Match
from src.domain.value_objects.odds import OddsSnapshot


class TeamRepository(ABC):
    @abstractmethod
    async def get_by_id(self, team_id: int) -> Team | None: ...

    @abstractmethod
    async def get_by_code(self, code: str) -> Team | None: ...

    @abstractmethod
    async def get_all(self) -> Sequence[Team]: ...

    @abstractmethod
    async def save(self, team: Team) -> Team: ...

    @abstractmethod
    async def update_elo(self, team_id: int, new_elo: float) -> None: ...


class MatchRepository(ABC):
    @abstractmethod
    async def get_by_id(self, match_id: int) -> Match | None: ...

    @abstractmethod
    async def get_team_matches(self, team_id: int, limit: int = 10) -> Sequence[Match]: ...

    @abstractmethod
    async def save(self, match: Match) -> Match: ...

    @abstractmethod
    async def get_tournament_matches(self, tournament: str) -> Sequence[Match]: ...


class OddsRepository(ABC):
    @abstractmethod
    async def get_latest(self, match_id: int) -> OddsSnapshot | None: ...

    @abstractmethod
    async def get_history(self, match_id: int) -> Sequence[OddsSnapshot]: ...

    @abstractmethod
    async def save(self, match_id: int, snapshot: OddsSnapshot) -> None: ...
