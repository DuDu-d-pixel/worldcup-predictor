"""Service interfaces (abstract base classes)."""
from __future__ import annotations
from abc import ABC, abstractmethod
from src.domain.entities.team import Team
from src.domain.entities.match import Match
from src.domain.value_objects.xg_stats import XGStats
from src.domain.value_objects.injury_report import InjuryReport


class EloServiceInterface(ABC):
    @abstractmethod
    def calculate_expected_score(self, team_a_elo: float, team_b_elo: float) -> float: ...

    @abstractmethod
    def update_ratings(
        self, team_a_elo: float, team_b_elo: float, actual_score_a: float, k_factor: float
    ) -> tuple[float, float]: ...


class XGServiceInterface(ABC):
    @abstractmethod
    def compute_team_xg(self, team_id: int, matches: list[Match]) -> XGStats: ...


class InjuryServiceInterface(ABC):
    @abstractmethod
    def compute_injury_report(self, team_id: int) -> InjuryReport: ...


class SentimentServiceInterface(ABC):
    @abstractmethod
    async def analyze_team_sentiment(self, team_id: int) -> float: ...
