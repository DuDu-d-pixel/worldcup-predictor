"""FastAPI application entry point."""
from __future__ import annotations
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from src.config import get_settings
from src.infrastructure.database.session import init_db
from src.api.routes import health, teams, predictions, simulation, odds, matches

STATIC_DIR = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan — startup and shutdown."""
    # Startup
    await init_db()

    # Start real-time update scheduler
    from src.services.scheduler import UpdateScheduler
    scheduler = UpdateScheduler(interval_minutes=15)
    app.state.scheduler = scheduler
    await scheduler.start()

    yield

    # Shutdown
    await scheduler.stop()
    try:
        from src.api.dependencies import get_redis_cache
        cache = get_redis_cache()
        await cache.close()
    except Exception:
        pass


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="World Cup Champion Probability Prediction Platform — "
                    "Elo, xG, Injury, Sentiment, and Monte Carlo simulation.",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # API routes
    app.include_router(health.router, prefix="/api/v1")
    app.include_router(teams.router, prefix="/api/v1")
    app.include_router(predictions.router, prefix="/api/v1")
    app.include_router(simulation.router, prefix="/api/v1")
    app.include_router(odds.router, prefix="/api/v1")
    app.include_router(matches.router, prefix="/api/v1")

    # Serve frontend pages
    @app.get("/", include_in_schema=False)
    async def serve_frontend():
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/matches", include_in_schema=False)
    async def serve_matches():
        return FileResponse(STATIC_DIR / "matches.html")

    # Mount static files
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("src.main:app", host="0.0.0.0", port=8000, reload=True)
