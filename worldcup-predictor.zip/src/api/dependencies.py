"""FastAPI dependency injection."""
from __future__ import annotations
from functools import lru_cache
from sqlalchemy.ext.asyncio import AsyncSession
from src.config import Settings, get_settings
from src.infrastructure.database.session import get_session
from src.infrastructure.cache.redis_cache import RedisCache
from src.services.elo_service import EloService
from src.services.xg_service import XGService
from src.services.injury_service import InjuryService
from src.services.odds_service import OddsService
from src.services.sentiment_service import SentimentService
from src.services.feature_engineering import FeatureEngineering
from src.services.xgboost_service import XGBoostService
from src.services.monte_carlo_service import MonteCarloService


@lru_cache
def get_elo_service() -> EloService:
    return EloService()


@lru_cache
def get_xg_service() -> XGService:
    return XGService()


@lru_cache
def get_injury_service() -> InjuryService:
    return InjuryService()


@lru_cache
def get_odds_service() -> OddsService:
    return OddsService()


@lru_cache
def get_sentiment_service() -> SentimentService:
    settings = get_settings()
    return SentimentService(model_name=settings.sentiment_model_name)


@lru_cache
def get_feature_engineering() -> FeatureEngineering:
    return FeatureEngineering(
        elo_service=get_elo_service(),
        xg_service=get_xg_service(),
        injury_service=get_injury_service(),
        odds_service=get_odds_service(),
    )


@lru_cache
def get_xgboost_service() -> XGBoostService:
    settings = get_settings()
    service = XGBoostService(model_path=settings.model_path)
    try:
        service.load_model()
    except Exception:
        pass  # Model not trained yet
    return service


@lru_cache
def get_monte_carlo_service() -> MonteCarloService:
    return MonteCarloService(model_service=get_xgboost_service())


@lru_cache
def get_redis_cache() -> RedisCache:
    return RedisCache()
