"""Odds endpoints — simplified for new schema."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database.session import get_session
from src.infrastructure.database.models import OddsModel

router = APIRouter(prefix="/odds", tags=["odds"])


class OddsItem(BaseModel):
    bookmaker: str
    team: str
    odds: float
    implied_prob: float


class OddsListResponse(BaseModel):
    team: str
    odds: list[OddsItem]
    avg_implied_prob: float


class AllOddsResponse(BaseModel):
    teams: dict[str, list[OddsItem]]


@router.get("/team/{team_name}", response_model=OddsListResponse)
async def get_team_odds(
    team_name: str,
    session: AsyncSession = Depends(get_session),
) -> OddsListResponse:
    """Get all bookmaker odds for a specific team."""
    result = await session.execute(
        select(OddsModel).where(OddsModel.team == team_name)
    )
    odds = result.scalars().all()

    if not odds:
        raise HTTPException(status_code=404, detail=f"No odds for {team_name}")

    items = [
        OddsItem(bookmaker=o.bookmaker, team=o.team, odds=o.odds, implied_prob=o.implied_prob)
        for o in odds
    ]
    avg_prob = sum(o.implied_prob for o in odds) / len(odds)

    return OddsListResponse(team=team_name, odds=items, avg_implied_prob=round(avg_prob, 4))


@router.get("", response_model=AllOddsResponse)
async def get_all_odds(
    session: AsyncSession = Depends(get_session),
) -> AllOddsResponse:
    """Get all odds grouped by team."""
    result = await session.execute(select(OddsModel))
    all_odds = result.scalars().all()

    grouped: dict[str, list[OddsItem]] = {}
    for o in all_odds:
        grouped.setdefault(o.team, []).append(
            OddsItem(bookmaker=o.bookmaker, team=o.team, odds=o.odds, implied_prob=o.implied_prob)
        )

    return AllOddsResponse(teams=grouped)
