"""Simulation endpoints — simplified for new schema."""
from __future__ import annotations
import uuid
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database.session import get_session, async_session_factory
from src.infrastructure.database.models import TeamModel, PredictionModel
from src.services.monte_carlo_service import MonteCarloService, TeamConfig
from src.services.xgboost_service import XGBoostService

router = APIRouter(prefix="/simulations", tags=["simulations"])

_tasks: dict[str, dict] = {}


class SimulationRequest(BaseModel):
    num_simulations: int = Field(default=50_000, ge=1000, le=500_000)
    seed: int | None = 42


class SimulationResponse(BaseModel):
    message: str
    task_id: str
    status: str = "running"


class SimulationTeamResult(BaseModel):
    team: str
    win_probability: float
    group_stage_prob: float = 0.0
    round_of_16_prob: float = 0.0
    quarter_final_prob: float = 0.0
    semi_final_prob: float = 0.0
    final_prob: float = 0.0


class SimulationStatusResponse(BaseModel):
    task_id: str
    status: str
    result: list[SimulationTeamResult] | None = None
    total_simulations: int = 0


async def _run_simulation_background(task_id: str, num_simulations: int, seed: int | None) -> None:
    """Background task: run Monte Carlo simulation and persist results."""
    try:
        _tasks[task_id]["status"] = "running"

        async with async_session_factory() as session:
            result = await session.execute(select(TeamModel))
            db_teams = result.scalars().all()

            if not db_teams:
                _tasks[task_id]["status"] = "failed"
                _tasks[task_id]["error"] = "No teams in database"
                return

            team_configs = [
                TeamConfig(
                    team_id=t.id, code=t.code, name=t.name,
                    group=t.group_name or "A", elo=t.elo,
                    xg_diff=t.xg - t.xga,
                    injury_score=t.injury_score,
                    sentiment_score=t.sentiment,
                )
                for t in db_teams
            ]

            xgb = XGBoostService()
            mc = MonteCarloService(xgb)
            tournament = mc.simulate_tournament(team_configs, num_simulations=num_simulations, seed=seed)

            # Persist to predictions table
            await session.execute(delete(PredictionModel))
            for sim in tournament.sorted_by_win_prob:
                pred = PredictionModel(
                    team=sim.team_name,
                    win_probability=round(sim.win_probability, 4),
                    group_stage_prob=round(sim.r16_probability, 4),
                    round_of_16_prob=round(sim.r16_probability, 4),
                    quarter_final_prob=round(sim.quarter_probability, 4),
                    semi_final_prob=round(sim.semi_probability, 4),
                    final_prob=round(sim.final_probability, 4),
                    simulations_count=num_simulations,
                )
                session.add(pred)

                # Update team table
                team = next((t for t in db_teams if t.id == sim.team_id), None)
                if team:
                    team.win_probability = round(sim.win_probability, 4)

            await session.commit()

            _tasks[task_id]["status"] = "completed"
            _tasks[task_id]["result"] = [
                SimulationTeamResult(
                    team=sim.team_name,
                    win_probability=sim.win_probability,
                    group_stage_prob=sim.r16_probability,
                    round_of_16_prob=sim.r16_probability,
                    quarter_final_prob=sim.quarter_probability,
                    semi_final_prob=sim.semi_probability,
                    final_prob=sim.final_probability,
                )
                for sim in tournament.sorted_by_win_prob
            ]

    except Exception as e:
        import traceback
        _tasks[task_id]["status"] = "failed"
        _tasks[task_id]["error"] = str(e)
        traceback.print_exc()


@router.post("/run", response_model=SimulationResponse)
async def run_simulation(
    request: SimulationRequest,
    background_tasks: BackgroundTasks,
) -> SimulationResponse:
    """Trigger a Monte Carlo simulation (runs in background)."""
    task_id = str(uuid.uuid4())[:8]
    _tasks[task_id] = {"status": "pending", "result": None, "error": None}

    background_tasks.add_task(
        _run_simulation_background, task_id, request.num_simulations, request.seed,
    )

    return SimulationResponse(
        message=f"Simulation started with {request.num_simulations:,} iterations",
        task_id=task_id, status="pending",
    )


@router.get("/{task_id}", response_model=SimulationStatusResponse)
async def get_simulation_status(task_id: str) -> SimulationStatusResponse:
    """Check simulation status and get results."""
    task = _tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    return SimulationStatusResponse(
        task_id=task_id, status=task["status"],
        result=task.get("result"),
    )


@router.get("", response_model=SimulationStatusResponse)
async def get_latest_simulation(
    session: AsyncSession = Depends(get_session),
) -> SimulationStatusResponse:
    """Get latest simulation results from database."""
    result = await session.execute(
        select(PredictionModel).order_by(PredictionModel.win_probability.desc())
    )
    preds = result.scalars().all()

    if not preds:
        return SimulationStatusResponse(task_id="latest", status="no_data", result=[])

    return SimulationStatusResponse(
        task_id="latest", status="completed",
        result=[
            SimulationTeamResult(
                team=p.team,
                win_probability=p.win_probability,
                group_stage_prob=p.group_stage_prob or 0.0,
                round_of_16_prob=p.round_of_16_prob or 0.0,
                quarter_final_prob=p.quarter_final_prob or 0.0,
                semi_final_prob=p.semi_final_prob or 0.0,
                final_prob=p.final_prob or 0.0,
            )
            for p in preds
        ],
        total_simulations=preds[0].simulations_count if preds else 0,
    )
