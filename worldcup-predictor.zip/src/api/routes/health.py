"""Health check endpoint."""
from __future__ import annotations
from fastapi import APIRouter
from src.schemas.common import HealthResponse
from src.config import get_settings

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(
        status="ok",
        version=settings.app_version,
    )
