"""Team endpoints — simplified for new schema."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database.session import get_session
from src.infrastructure.database.models import TeamModel, PlayerModel

router = APIRouter(prefix="/teams", tags=["teams"])


class TeamResponse(BaseModel):
    id: int
    name: str
    code: str
    group: str | None = None
    elo: float
    xg: float
    xga: float
    sentiment: float
    injury_score: float
    win_probability: float
    squad_value: float

    model_config = {"from_attributes": True}


class TeamDetailResponse(TeamResponse):
    players: list[dict] = []


class TeamListResponse(BaseModel):
    teams: list[TeamResponse]
    total: int


@router.get("", response_model=TeamListResponse)
async def list_teams(
    session: AsyncSession = Depends(get_session),
) -> TeamListResponse:
    """Get all teams."""
    result = await session.execute(select(TeamModel).order_by(TeamModel.elo.desc()))
    teams = result.scalars().all()

    items = [
        TeamResponse(
            id=t.id, name=t.name, code=t.code, group=t.group_name,
            elo=t.elo, xg=t.xg, xga=t.xga,
            sentiment=t.sentiment, injury_score=t.injury_score,
            win_probability=t.win_probability, squad_value=t.squad_value,
        )
        for t in teams
    ]
    return TeamListResponse(teams=items, total=len(items))


@router.get("/{code}", response_model=TeamDetailResponse)
async def get_team(
    code: str,
    session: AsyncSession = Depends(get_session),
) -> TeamDetailResponse:
    """Get team details by FIFA code."""
    result = await session.execute(
        select(TeamModel).where(TeamModel.code == code.upper())
    )
    team = result.scalar_one_or_none()
    if not team:
        raise HTTPException(status_code=404, detail=f"Team {code} not found")

    # Get players
    players_result = await session.execute(
        select(PlayerModel).where(PlayerModel.team_id == team.id)
    )
    players = players_result.scalars().all()

    return TeamDetailResponse(
        id=team.id, name=team.name, code=team.code, group=team.group_name,
        elo=team.elo, xg=team.xg, xga=team.xga,
        sentiment=team.sentiment, injury_score=team.injury_score,
        win_probability=team.win_probability, squad_value=team.squad_value,
        players=[
            {"name": p.name, "position": p.position, "market_value": p.market_value,
             "form_score": p.form_score, "injured": p.injury}
            for p in players
        ],
    )
