"""Prediction endpoints — simplified for new schema."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database.session import get_session
from src.infrastructure.database.models import TeamModel, PredictionModel
from src.api.dependencies import get_xgboost_service

router = APIRouter(prefix="/predictions", tags=["predictions"])


class PredictionItem(BaseModel):
    team: str
    team_cn: str = ""
    team_code: str = ""
    win_probability: float
    group_stage_prob: float = 0.0
    round_of_16_prob: float = 0.0
    quarter_final_prob: float = 0.0
    semi_final_prob: float = 0.0
    final_prob: float = 0.0


class PredictionListResponse(BaseModel):
    predictions: list[PredictionItem]
    total_simulations: int = 0


class MatchPredictionRequest(BaseModel):
    home_team_code: str = Field(..., min_length=3, max_length=3)
    away_team_code: str = Field(..., min_length=3, max_length=3)


class MatchPredictionResponse(BaseModel):
    home_team: str
    away_team: str
    home_win_prob: float
    draw_prob: float
    away_win_prob: float
    predicted_result: str


@router.get("", response_model=PredictionListResponse)
async def get_predictions(
    session: AsyncSession = Depends(get_session),
) -> PredictionListResponse:
    """Get latest championship predictions for all teams."""
    result = await session.execute(
        select(PredictionModel).order_by(PredictionModel.win_probability.desc())
    )
    preds = result.scalars().all()

    if not preds:
        return PredictionListResponse(predictions=[], total_simulations=0)

    # Build code and Chinese name lookup
    teams_result = await session.execute(select(TeamModel))
    code_map = {t.name: t.code for t in teams_result.scalars().all()}
    cn_map = {t.name: t.name_cn for t in teams_result.scalars().all()}

    items = [
        PredictionItem(
            team=p.team,
            team_cn=p.team_cn or cn_map.get(p.team, p.team),
            team_code=code_map.get(p.team, ""),
            win_probability=p.win_probability,
            group_stage_prob=p.group_stage_prob or 0.0,
            round_of_16_prob=p.round_of_16_prob or 0.0,
            quarter_final_prob=p.quarter_final_prob or 0.0,
            semi_final_prob=p.semi_final_prob or 0.0,
            final_prob=p.final_prob or 0.0,
        )
        for p in preds
    ]

    return PredictionListResponse(
        predictions=items,
        total_simulations=preds[0].simulations_count if preds else 0,
    )


@router.get("/{team_name}", response_model=PredictionItem)
async def get_team_prediction(
    team_name: str,
    session: AsyncSession = Depends(get_session),
) -> PredictionItem:
    """Get prediction for a specific team."""
    result = await session.execute(
        select(PredictionModel).where(PredictionModel.team == team_name)
    )
    pred = result.scalar_one_or_none()
    if not pred:
        raise HTTPException(status_code=404, detail=f"No prediction for {team_name}")

    # Get team code
    team_result = await session.execute(
        select(TeamModel).where(TeamModel.name == team_name)
    )
    team = team_result.scalar_one_or_none()

    return PredictionItem(
        team=pred.team,
        team_code=team.code if team else "",
        win_probability=pred.win_probability,
        group_stage_prob=pred.group_stage_prob or 0.0,
        round_of_16_prob=pred.round_of_16_prob or 0.0,
        quarter_final_prob=pred.quarter_final_prob or 0.0,
        semi_final_prob=pred.semi_final_prob or 0.0,
        final_prob=pred.final_prob or 0.0,
    )


@router.post("/match", response_model=MatchPredictionResponse)
async def predict_match(
    request: MatchPredictionRequest,
    session: AsyncSession = Depends(get_session),
    xgb_service=Depends(get_xgboost_service),
) -> MatchPredictionResponse:
    """Predict outcome of a specific match."""
    home_result = await session.execute(
        select(TeamModel).where(TeamModel.code == request.home_team_code.upper())
    )
    home_team = home_result.scalar_one_or_none()
    away_result = await session.execute(
        select(TeamModel).where(TeamModel.code == request.away_team_code.upper())
    )
    away_team = away_result.scalar_one_or_none()

    if not home_team:
        raise HTTPException(status_code=404, detail=f"Team {request.home_team_code} not found")
    if not away_team:
        raise HTTPException(status_code=404, detail=f"Team {request.away_team_code} not found")

    prediction = xgb_service.predict_match_probabilities(
        home_elo=home_team.elo,
        away_elo=away_team.elo,
        home_xg_diff=home_team.xg - home_team.xga,
        away_xg_diff=away_team.xg - away_team.xga,
        home_injury=home_team.injury_score,
        away_injury=away_team.injury_score,
        home_sentiment=home_team.sentiment,
        away_sentiment=away_team.sentiment,
    )

    return MatchPredictionResponse(
        home_team=home_team.name,
        away_team=away_team.name,
        home_win_prob=prediction.home_win_prob,
        draw_prob=prediction.draw_prob,
        away_win_prob=prediction.away_win_prob,
        predicted_result=prediction.predicted_result,
    )
