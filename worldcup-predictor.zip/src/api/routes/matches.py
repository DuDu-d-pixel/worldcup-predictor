"""Match schedule endpoints with predictions and handicap odds."""
from __future__ import annotations
from datetime import datetime
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.infrastructure.database.session import get_session
from src.infrastructure.database.models import MatchModel, TeamModel

router = APIRouter(prefix="/matches", tags=["matches"])


class MatchPrediction(BaseModel):
    match_id: int
    match_time: str
    group: str
    home_team: str
    away_team: str
    home_team_cn: str
    away_team_cn: str
    home_elo: float
    away_elo: float
    home_xg: float
    away_xg: float
    # 胜负概率
    home_win_prob: float
    draw_prob: float
    away_win_prob: float
    predicted_result: str  # "主胜" "平局" "客胜"
    # 让球盘 (亚洲盘口)
    handicap: float  # 正数=主队让球, 负数=客队让球
    handicap_home_odds: float
    handicap_away_odds: float
    # 大小球
    total_goals_line: float  # 大小球盘口 (e.g., 2.5)
    over_odds: float
    under_odds: float
    # 推荐
    recommendation: str
    confidence: str  # "高" "中" "低"
    bet_primary: str = ""       # 首选投注
    bet_secondary: str = ""     # 备选投注
    kelly_stake: str = ""       # 建议仓位


class MatchListResponse(BaseModel):
    matches: list[MatchPrediction]
    total: int


def _calculate_handicap(elo_diff: float, xg_diff: float, home_advantage: float = 100) -> float:
    """Calculate Asian handicap based on team strength difference.

    Positive = home team gives handicap (is favored)
    Negative = away team gives handicap
    """
    # Combined strength difference
    strength_diff = (elo_diff + home_advantage) / 400 + xg_diff * 0.3

    # Map to handicap lines (0, ±0.25, ±0.5, ±0.75, ±1, ±1.25, ±1.5, ±2)
    raw_handicap = strength_diff * 1.5
    # Round to nearest 0.25
    handicap = round(raw_handicap * 4) / 4
    # Clamp to reasonable range
    handicap = max(-3.0, min(3.0, handicap))
    return handicap


def _calculate_match_probs(home_elo: float, away_elo: float, home_xg: float, away_xg: float) -> tuple[float, float, float]:
    """Calculate home win, draw, away win probabilities."""
    import math

    elo_adv = (home_elo + 100) - away_elo  # +100 home advantage
    xg_adv = home_xg - away_xg

    # Base probability from Elo
    home_base = 1.0 / (1.0 + 10.0 ** (-elo_adv / 400.0))

    # xG adjustment
    xg_adj = xg_adj = xg_adv * 0.04

    home_prob = max(0.10, min(0.75, home_base + xg_adj))
    draw_prob = max(0.12, 0.28 - abs(xg_adv) * 0.03)
    away_prob = 1.0 - home_prob - draw_prob

    if away_prob < 0.08:
        away_prob = 0.08
        draw_prob = 1.0 - home_prob - away_prob

    return round(home_prob, 3), round(draw_prob, 3), round(away_prob, 3)


def _calculate_handicap_odds(handicap: float, home_prob: float, away_prob: float) -> tuple[float, float]:
    """Calculate handicap odds (Asian format)."""
    # Adjust probabilities for handicap
    # If handicap > 0, home gives goals → harder for home to cover
    adj_home = home_prob - handicap * 0.08
    adj_away = away_prob + handicap * 0.08

    # Convert to odds with margin
    margin = 0.92  # 8% bookmaker margin
    home_odds = round(margin / max(0.05, adj_home), 2)
    away_odds = round(margin / max(0.05, adj_away), 2)

    # Ensure reasonable odds range
    home_odds = max(1.50, min(4.00, home_odds))
    away_odds = max(1.50, min(4.00, away_odds))

    return home_odds, away_odds


def _calculate_over_under(home_xg: float, away_xg: float) -> tuple[float, float, float]:
    """Calculate over/under goals line and odds."""
    total_xg = home_xg + away_xg

    # Round to nearest 0.5
    line = round(total_xg * 2) / 2
    line = max(1.5, min(4.5, line))

    # Over probability based on Poisson
    import math
    lam = total_xg
    # P(X >= line+0.5) for over
    p_under = sum((lam ** k) * math.exp(-lam) / math.factorial(k) for k in range(int(line + 0.5)))
    p_over = 1.0 - p_under

    margin = 0.92
    over_odds = round(margin / max(0.10, p_over), 2)
    under_odds = round(margin / max(0.10, p_under), 2)

    over_odds = max(1.50, min(3.50, over_odds))
    under_odds = max(1.50, min(3.50, under_odds))

    return line, over_odds, under_odds


def _get_recommendation(home_prob: float, draw_prob: float, away_prob: float,
                        handicap: float, home_xg: float, away_xg: float,
                        h_odds: float, a_odds: float, over_odds: float, under_odds: float
                        ) -> tuple[str, str, str, str, str]:
    """Generate detailed betting recommendation with stakes."""
    max_prob = max(home_prob, draw_prob, away_prob)
    total_xg = home_xg + away_xg

    recommendations = []
    primary = ""
    secondary = ""
    kelly = ""

    # Win/loss recommendation
    if home_prob > 0.50:
        recommendations.append(f"主胜 ({home_prob:.0%})")
    elif away_prob > 0.45:
        recommendations.append(f"客胜 ({away_prob:.0%})")
    elif draw_prob > 0.28:
        recommendations.append(f"平局 ({draw_prob:.0%})")

    # Handicap recommendation
    if handicap > 0.5 and home_prob > 0.55:
        recommendations.append(f"让{handicap}球 主队可捧")
    elif handicap < -0.5 and away_prob > 0.50:
        recommendations.append(f"受让{abs(handicap)}球 客队可捧")

    # Over/under recommendation
    if total_xg > 2.8:
        recommendations.append(f"大球 (xG={total_xg:.1f})")
    elif total_xg < 1.8:
        recommendations.append(f"小球 (xG={total_xg:.1f})")

    # Confidence
    if max_prob > 0.55:
        confidence = "高"
    elif max_prob > 0.42:
        confidence = "中"
    else:
        confidence = "低"

    # Primary bet: strongest signal
    if home_prob > 0.60:
        primary = f"🔴 主胜 @{h_odds:.2f}"
        kelly = "重仓 ⭐⭐⭐" if home_prob > 0.65 else "标准仓 ⭐⭐"
    elif away_prob > 0.50:
        primary = f"🔵 客胜 @{a_odds:.2f}"
        kelly = "标准仓 ⭐⭐" if away_prob > 0.55 else "轻仓 ⭐"
    elif handicap > 0.75 and home_prob > 0.55:
        primary = f"🟡 让{handicap}球 主队 @1.90"
        kelly = "标准仓 ⭐⭐"
    elif handicap < -0.75 and away_prob > 0.48:
        primary = f"🟡 受让{abs(handicap)}球 客队 @1.90"
        kelly = "轻仓 ⭐"
    elif draw_prob > 0.30:
        primary = f"⚪ 平局 @{3.20:.2f}"
        kelly = "小注 ⭐"
    else:
        primary = "⚠️ 势均力敌 不推荐"
        kelly = "不投注 ❌"

    # Secondary bet: over/under
    if total_xg > 2.8 and over_odds < 2.20:
        secondary = f"⬆️ 大{total_xg:.1f}球 @{over_odds:.2f}"
    elif total_xg < 1.8 and under_odds < 2.20:
        secondary = f"⬇️ 小{total_xg:.1f}球 @{under_odds:.2f}"
    elif home_prob > 0.55 and total_xg > 2.5:
        secondary = f"⬆️ 大球 + 主胜 组合"
    else:
        secondary = ""

    rec = " | ".join(recommendations) if recommendations else "势均力敌，谨慎投注"
    return rec, confidence, primary, secondary, kelly


@router.get("", response_model=MatchListResponse)
async def list_matches(
    group: str | None = None,
    date: str | None = None,
    session: AsyncSession = Depends(get_session),
) -> MatchListResponse:
    """Get all matches with predictions and handicap odds."""
    query = select(MatchModel).order_by(MatchModel.match_date)
    if group:
        query = query.where(MatchModel.group_name == group.upper())

    result = await session.execute(query)
    matches = result.scalars().all()

    # Load all teams for Elo/xG lookup
    teams_result = await session.execute(select(TeamModel))
    team_map = {t.name: t for t in teams_result.scalars().all()}

    predictions = []
    for m in matches:
        home = team_map.get(m.home_team)
        away = team_map.get(m.away_team)
        if not home or not away:
            continue

        # Filter by date if specified
        if date and m.match_date.strftime("%Y-%m-%d") != date:
            continue

        h_elo, a_elo = home.elo, away.elo
        h_xg, a_xg = home.xg, away.xg

        h_prob, d_prob, a_prob = _calculate_match_probs(h_elo, a_elo, h_xg, a_xg)
        handicap = _calculate_handicap(h_elo - a_elo, h_xg - a_xg)
        h_odds, a_odds = _calculate_handicap_odds(handicap, h_prob, a_prob)
        line, over_odds, under_odds = _calculate_over_under(h_xg, a_xg)

        if h_prob > d_prob and h_prob > a_prob:
            result_str = "主胜"
        elif a_prob > d_prob and a_prob > h_prob:
            result_str = "客胜"
        else:
            result_str = "平局"

        rec, conf, primary, secondary, kelly = _get_recommendation(
            h_prob, d_prob, a_prob, handicap, h_xg, a_xg, h_odds, a_odds, over_odds, under_odds
        )

        predictions.append(MatchPrediction(
            match_id=m.id,
            match_time=m.match_date.strftime("%m月%d日 %H:%M"),
            group=m.group_name or "",
            home_team=m.home_team,
            away_team=m.away_team,
            home_team_cn=m.home_team_cn or home.name_cn or m.home_team,
            away_team_cn=m.away_team_cn or away.name_cn or m.away_team,
            home_elo=h_elo,
            away_elo=a_elo,
            home_xg=h_xg,
            away_xg=a_xg,
            home_win_prob=h_prob,
            draw_prob=d_prob,
            away_win_prob=a_prob,
            predicted_result=result_str,
            handicap=handicap,
            handicap_home_odds=h_odds,
            handicap_away_odds=a_odds,
            total_goals_line=line,
            over_odds=over_odds,
            under_odds=under_odds,
            recommendation=rec,
            confidence=conf,
            bet_primary=primary,
            bet_secondary=secondary,
            kelly_stake=kelly,
        ))

    return MatchListResponse(matches=predictions, total=len(predictions))


@router.get("/{match_id}", response_model=MatchPrediction)
async def get_match_prediction(
    match_id: int,
    session: AsyncSession = Depends(get_session),
) -> MatchPrediction:
    """Get prediction for a specific match."""
    result = await session.execute(select(MatchModel).where(MatchModel.id == match_id))
    match = result.scalar_one_or_none()

    teams_result = await session.execute(select(TeamModel))
    team_map = {t.name: t for t in teams_result.scalars().all()}

    home = team_map.get(match.home_team)
    away = team_map.get(match.away_team)

    h_elo, a_elo = home.elo, away.elo
    h_xg, a_xg = home.xg, away.xg
    h_prob, d_prob, a_prob = _calculate_match_probs(h_elo, a_elo, h_xg, a_xg)
    handicap = _calculate_handicap(h_elo - a_elo, h_xg - a_xg)
    h_odds, a_odds = _calculate_handicap_odds(handicap, h_prob, a_prob)
    line, over_odds, under_odds = _calculate_over_under(h_xg, a_xg)

    if h_prob > d_prob and h_prob > a_prob:
        result_str = "主胜"
    elif a_prob > d_prob and a_prob > h_prob:
        result_str = "客胜"
    else:
        result_str = "平局"

    rec, conf = _get_recommendation(h_prob, d_prob, a_prob, handicap, h_xg, a_xg)

    return MatchPrediction(
        match_id=match.id,
        match_time=match.match_date.strftime("%m月%d日 %H:%M"),
        group=match.group_name or "",
        home_team=match.home_team,
        away_team=match.away_team,
        home_elo=h_elo, away_elo=a_elo,
        home_xg=h_xg, away_xg=a_xg,
        home_win_prob=h_prob, draw_prob=d_prob, away_win_prob=a_prob,
        predicted_result=result_str,
        handicap=handicap,
        handicap_home_odds=h_odds, handicap_away_odds=a_odds,
        total_goals_line=line, over_odds=over_odds, under_odds=under_odds,
        recommendation=rec, confidence=conf,
    )
