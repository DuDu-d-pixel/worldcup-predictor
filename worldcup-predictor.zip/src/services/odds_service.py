"""Odds implied probability conversion and movement analysis."""
from __future__ import annotations
from dataclasses import dataclass
from src.domain.value_objects.odds import OddsSnapshot, OddsMovement


# Default bookmaker weights for aggregation
_DEFAULT_WEIGHTS: dict[str, float] = {
    "bet365": 0.40,
    "pinnacle": 0.35,
    "william_hill": 0.25,
}


@dataclass
class AggregatedOdds:
    """Aggregated odds from multiple bookmakers."""
    home_win_prob: float
    draw_prob: float
    away_win_prob: float
    overround: float
    num_bookmakers: int
    confidence: float  # 0-1, based on agreement between bookmakers


@dataclass
class OddsMovementAnalysis:
    """Analysis of how odds have moved over time."""
    home_prob_shift: float       # Change in implied probability (positive = more favored)
    draw_prob_shift: float
    away_prob_shift: float
    home_odds_change_pct: float  # Percentage change in raw odds
    draw_odds_change_pct: float
    away_odds_change_pct: float
    steam_move: bool             # True if significant synchronized movement
    direction: str               # "home", "away", "balanced"


class OddsService:
    """Converts and analyzes betting odds."""

    def implied_probability(self, decimal_odds: float) -> float:
        """Convert decimal odds to implied probability.

        Args:
            decimal_odds: European decimal odds (e.g., 2.50).

        Returns:
            Implied probability in (0, 1).
        """
        if decimal_odds <= 1.0:
            raise ValueError(f"Odds must be > 1.0, got {decimal_odds}")
        return 1.0 / decimal_odds

    def remove_overround(
        self, home_odds: float, draw_odds: float, away_odds: float
    ) -> tuple[float, float, float]:
        """Convert bookmaker odds to fair probabilities (sum to 1.0).

        Args:
            home_odds: Home win decimal odds.
            draw_odds: Draw decimal odds.
            away_odds: Away win decimal odds.

        Returns:
            Tuple of (home_prob, draw_prob, away_prob) summing to 1.0.
        """
        p_h = self.implied_probability(home_odds)
        p_d = self.implied_probability(draw_odds)
        p_a = self.implied_probability(away_odds)
        total = p_h + p_d + p_a
        return (p_h / total, p_d / total, p_a / total)

    def aggregate_odds(
        self,
        snapshots: list[OddsSnapshot],
        weights: dict[str, float] | None = None,
    ) -> AggregatedOdds:
        """Aggregate odds from multiple bookmakers using weighted average.

        Args:
            snapshots: List of OddsSnapshot from different bookmakers.
            weights: Optional custom weights; defaults to _DEFAULT_WEIGHTS.

        Returns:
            AggregatedOdds with weighted fair probabilities.
        """
        if not snapshots:
            return AggregatedOdds(0.0, 0.0, 0.0, 0.0, 0, 0.0)

        if weights is None:
            weights = _DEFAULT_WEIGHTS

        weighted_home = 0.0
        weighted_draw = 0.0
        weighted_away = 0.0
        total_weight = 0.0

        for snap in snapshots:
            w = weights.get(snap.bookmaker, 1.0 / len(snapshots))
            p_h, p_d, p_a = snap.fair_probs
            weighted_home += w * p_h
            weighted_draw += w * p_d
            weighted_away += w * p_a
            total_weight += w

        if total_weight > 0:
            weighted_home /= total_weight
            weighted_draw /= total_weight
            weighted_away /= total_weight

        # Confidence: based on how much bookmakers agree
        probs = []
        for snap in snapshots:
            probs.append(snap.fair_probs)
        if len(probs) >= 2:
            import numpy as np
            std_home = float(np.std([p[0] for p in probs]))
            std_draw = float(np.std([p[1] for p in probs]))
            std_away = float(np.std([p[2] for p in probs]))
            avg_std = (std_home + std_draw + std_away) / 3.0
            confidence = max(0.0, 1.0 - avg_std * 10)  # Scale: 0 std = 1.0 confidence
        else:
            confidence = 0.5

        overround = sum(1.0 / s.home_win for s in snapshots) / len(snapshots) - 1.0

        return AggregatedOdds(
            home_win_prob=round(weighted_home, 4),
            draw_prob=round(weighted_draw, 4),
            away_win_prob=round(weighted_away, 4),
            overround=round(overround, 4),
            num_bookmakers=len(snapshots),
            confidence=round(confidence, 4),
        )

    def analyze_movement(self, movement: OddsMovement) -> OddsMovementAnalysis:
        """Analyze odds movement for steam moves and market direction.

        Args:
            movement: OddsMovement comparing opening to current odds.

        Returns:
            OddsMovementAnalysis with shifts and direction.
        """
        p_open = movement.opening.fair_probs
        p_curr = movement.current.fair_probs

        home_shift = p_curr[0] - p_open[0]
        draw_shift = p_curr[1] - p_open[1]
        away_shift = p_curr[2] - p_open[2]

        # Steam move: significant shift (>3% probability) in one direction
        threshold = 0.03
        steam = abs(home_shift) > threshold or abs(away_shift) > threshold

        if home_shift > threshold and away_shift < -threshold:
            direction = "home"
        elif away_shift > threshold and home_shift < -threshold:
            direction = "away"
        else:
            direction = "balanced"

        return OddsMovementAnalysis(
            home_prob_shift=round(home_shift, 4),
            draw_prob_shift=round(draw_shift, 4),
            away_prob_shift=round(away_shift, 4),
            home_odds_change_pct=round(movement.home_win_change, 4),
            draw_odds_change_pct=round(movement.draw_change, 4),
            away_odds_change_pct=round(movement.away_win_change, 4),
            steam_move=steam,
            direction=direction,
        )

    def odds_to_features(
        self, aggregated: AggregatedOdds, movement: OddsMovementAnalysis | None = None
    ) -> dict[str, float]:
        """Convert odds analysis to feature dict for ML model.

        Args:
            aggregated: Aggregated odds.
            movement: Optional movement analysis.

        Returns:
            Dict of feature name -> value.
        """
        features: dict[str, float] = {
            "odds_home_prob": aggregated.home_win_prob,
            "odds_draw_prob": aggregated.draw_prob,
            "odds_away_prob": aggregated.away_win_prob,
            "odds_overround": aggregated.overround,
            "odds_confidence": aggregated.confidence,
        }
        if movement:
            features.update({
                "odds_home_shift": movement.home_prob_shift,
                "odds_away_shift": movement.away_prob_shift,
                "odds_steam_move": float(movement.steam_move),
            })
        return features
