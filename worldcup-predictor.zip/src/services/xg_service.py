"""Expected Goals (xG) feature engineering service."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from src.domain.entities.match import Match
from src.domain.value_objects.xg_stats import XGStats


@dataclass
class XGFeatures:
    """Complete xG feature set for a team, ready for ML consumption."""
    xg_10g: float          # xG per match, last 10 games
    xga_10g: float         # xGA per match, last 10 games
    xg_diff_10g: float     # xG - xGA, last 10 games
    xg_trend: float        # Slope of xG over last 10 games
    xg_home: float         # xG per match at home
    xg_away: float         # xG per match away
    xg_vs_strong: float    # xG vs top-20 Elo teams
    xg_conceded_rate: float  # xGA / opponent xG ratio


class XGService:
    """Computes xG-based features from match history."""

    def compute_team_xg(self, matches: list[Match], team_id: int) -> XGStats:
        """Compute aggregate xG stats for a team from its recent matches.

        Args:
            matches: List of matches (most recent first).
            team_id: The team to compute xG for.

        Returns:
            XGStats value object.
        """
        xgs_for: list[float] = []
        xgs_against: list[float] = []

        for match in matches:
            if match.home_team_id == team_id:
                if match.home_xg is not None:
                    xgs_for.append(match.home_xg)
                if match.away_xg is not None:
                    xgs_against.append(match.away_xg)
            elif match.away_team_id == team_id:
                if match.away_xg is not None:
                    xgs_for.append(match.away_xg)
                if match.home_xg is not None:
                    xgs_against.append(match.home_xg)

        return XGStats.from_match_xgs(xgs_for, xgs_against)

    def compute_xg_features(
        self,
        matches: list[Match],
        team_id: int,
        strong_team_ids: set[int] | None = None,
    ) -> XGFeatures:
        """Compute full xG feature set for ML model input.

        Args:
            matches: Recent matches (most recent first), up to ~30.
            team_id: Target team.
            strong_team_ids: Set of top-20 team IDs for strong-opponent xG.

        Returns:
            XGFeatures dataclass ready for feature vector construction.
        """
        if strong_team_ids is None:
            strong_team_ids = set()

        # Split into home/away
        home_xgs_for: list[float] = []
        home_xgs_against: list[float] = []
        away_xgs_for: list[float] = []
        away_xgs_against: list[float] = []
        strong_xgs_for: list[float] = []
        all_xgs_for: list[float] = []
        all_xgs_against: list[float] = []

        for match in matches:
            is_home = match.home_team_id == team_id
            opponent_id = match.away_team_id if is_home else match.home_team_id

            if is_home:
                xgf = match.home_xg
                xga = match.away_xg
                if xgf is not None:
                    home_xgs_for.append(xgf)
                    all_xgs_for.append(xgf)
                if xga is not None:
                    home_xgs_against.append(xga)
                    all_xgs_against.append(xga)
            else:
                xgf = match.away_xg
                xga = match.home_xg
                if xgf is not None:
                    away_xgs_for.append(xgf)
                    all_xgs_for.append(xgf)
                if xga is not None:
                    away_xgs_against.append(xga)
                    all_xgs_against.append(xga)

            # Strong opponent filter
            if opponent_id in strong_team_ids and xgf is not None:
                strong_xgs_for.append(xgf)

        # Compute last-10 aggregate stats
        last10 = XGStats.from_match_xgs(all_xgs_for[:10], all_xgs_against[:10])

        # Home/away splits
        xg_home = float(np.mean(home_xgs_for)) if home_xgs_for else 0.0
        xg_away = float(np.mean(away_xgs_for)) if away_xgs_for else 0.0
        xg_vs_strong = float(np.mean(strong_xgs_for)) if strong_xgs_for else last10.xg_per_match

        # Conceded rate: xGA / opponent average xG (proxy: use xGA / xG_diff ratio)
        xg_conceded_rate = (
            last10.xga_per_match / last10.xg_per_match
            if last10.xg_per_match > 0
            else 1.0
        )

        return XGFeatures(
            xg_10g=last10.xg_per_match,
            xga_10g=last10.xga_per_match,
            xg_diff_10g=last10.xg_diff,
            xg_trend=last10.xg_trend,
            xg_home=round(xg_home, 3),
            xg_away=round(xg_away, 3),
            xg_vs_strong=round(xg_vs_strong, 3),
            xg_conceded_rate=round(xg_conceded_rate, 3),
        )
