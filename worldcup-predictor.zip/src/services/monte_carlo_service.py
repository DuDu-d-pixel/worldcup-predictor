"""Monte Carlo World Cup simulation engine."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
from src.services.xgboost_service import XGBoostService, MatchPrediction


class Stage(str, Enum):
    GROUP = "group"
    ROUND_OF_16 = "round_of_16"
    QUARTER_FINAL = "quarter_final"
    SEMI_FINAL = "semi_final"
    FINAL = "final"
    WINNER = "winner"


@dataclass
class TeamConfig:
    """Configuration for a team in the simulation."""
    team_id: int
    code: str
    name: str
    group: str
    elo: float
    xg_diff: float = 0.0
    injury_score: float = 0.0
    sentiment_score: float = 0.0


@dataclass
class GroupStanding:
    """Group stage standing for a team."""
    team_id: int
    points: int = 0
    goal_diff: int = 0
    goals_for: int = 0


@dataclass
class SimulationResult:
    """Result of Monte Carlo simulation for one team."""
    team_id: int
    team_code: str
    team_name: str
    win_count: int = 0
    final_count: int = 0
    semi_count: int = 0
    quarter_count: int = 0
    r16_count: int = 0
    group_count: int = 0
    total_simulations: int = 0

    @property
    def win_probability(self) -> float:
        return self.win_count / self.total_simulations if self.total_simulations > 0 else 0.0

    @property
    def final_probability(self) -> float:
        return self.final_count / self.total_simulations if self.total_simulations > 0 else 0.0

    @property
    def semi_probability(self) -> float:
        return self.semi_count / self.total_simulations if self.total_simulations > 0 else 0.0

    @property
    def quarter_probability(self) -> float:
        return self.quarter_count / self.total_simulations if self.total_simulations > 0 else 0.0

    @property
    def r16_probability(self) -> float:
        return self.r16_count / self.total_simulations if self.total_simulations > 0 else 0.0


@dataclass
class TournamentResult:
    """Complete simulation results for all teams."""
    results: list[SimulationResult]
    total_simulations: int
    model_version: str = "1.0"

    @property
    def sorted_by_win_prob(self) -> list[SimulationResult]:
        return sorted(self.results, key=lambda r: r.win_probability, reverse=True)


class MonteCarloService:
    """Simulates World Cup tournaments using Monte Carlo methods."""

    def __init__(self, model_service: XGBoostService) -> None:
        self._model = model_service

    def simulate_tournament(
        self,
        teams: list[TeamConfig],
        num_simulations: int = 100_000,
        seed: int | None = 42,
    ) -> TournamentResult:
        """Run full Monte Carlo simulation of the World Cup.

        Args:
            teams: List of 48 (or 32) teams with their configs.
            num_simulations: Number of tournament simulations.
            seed: Random seed for reproducibility.

        Returns:
            TournamentResult with probabilities for each team.
        """
        rng = np.random.default_rng(seed)

        # Initialize counters
        counters: dict[int, SimulationResult] = {}
        for t in teams:
            counters[t.team_id] = SimulationResult(
                team_id=t.team_id,
                team_code=t.code,
                team_name=t.name,
                total_simulations=num_simulations,
            )

        # Group teams by group
        groups: dict[str, list[TeamConfig]] = {}
        for t in teams:
            groups.setdefault(t.group, []).append(t)

        for _ in range(num_simulations):
            self._simulate_one_tournament(teams, groups, counters, rng)

        results = list(counters.values())
        return TournamentResult(
            results=results,
            total_simulations=num_simulations,
        )

    def _simulate_one_tournament(
        self,
        teams: list[TeamConfig],
        groups: dict[str, list[TeamConfig]],
        counters: dict[int, SimulationResult],
        rng: np.random.Generator,
    ) -> None:
        """Simulate one full tournament (48-team format: 12 groups → 32-team knockout)."""
        # Stage 1: Group stage
        group_standings: dict[str, list[tuple[TeamConfig, GroupStanding]]] = {}
        for group_name, group_teams in groups.items():
            standings = self._simulate_group_stage(group_teams, rng)
            group_standings[group_name] = [
                (next(t for t in group_teams if t.team_id == s.team_id), s)
                for s in standings
            ]

        # Top 2 from each group advance (24 teams)
        advancing_teams: list[TeamConfig] = []
        for group_name, entries in group_standings.items():
            for team, standing in entries[:2]:
                advancing_teams.append(team)
                counters[team.team_id].group_count += 1

        # Best 3rd-place teams (8 out of 12) → total 32 teams
        third_place = [(team, standing) for _, entries in group_standings.items()
                       for team, standing in [entries[2]] if len(entries) >= 3]
        # Sort 3rd-place teams by points, then goal diff
        third_place.sort(key=lambda x: (x[1].points, x[1].goal_diff, x[1].goals_for), reverse=True)
        for team, _ in third_place[:8]:
            advancing_teams.append(team)
            counters[team.team_id].group_count += 1

        # Shuffle to avoid predictable bracket (simulates draw)
        advancing_list = list(advancing_teams)
        rng.shuffle(advancing_list)

        # Stage 2: Knockout rounds (32 → 16 → 8 → 4 → 2 → 1)
        current_round = advancing_list

        # Round of 32 (1/16决赛)
        if len(current_round) >= 32:
            r32_winners = self._simulate_knockout_round(current_round[:32], rng)
            for t in r32_winners:
                counters[t.team_id].r16_count += 1
            current_round = r32_winners

        # Round of 16 (1/8决赛)
        if len(current_round) >= 16:
            r16_winners = self._simulate_knockout_round(current_round[:16], rng)
            for t in r16_winners:
                counters[t.team_id].r16_count += 1
            current_round = r16_winners

        # Quarter-finals
        if len(current_round) >= 8:
            qf_winners = self._simulate_knockout_round(current_round[:8], rng)
            for t in qf_winners:
                counters[t.team_id].quarter_count += 1
            current_round = qf_winners

        # Semi-finals
        if len(current_round) >= 4:
            sf_winners = self._simulate_knockout_round(current_round[:4], rng)
            for t in sf_winners:
                counters[t.team_id].semi_count += 1
            current_round = sf_winners

        # Final
        if len(current_round) >= 2:
            finalists = current_round[:2]
            winner = self._simulate_knockout_round(finalists, rng)
            if winner:
                counters[winner[0].team_id].final_count += 1
                counters[winner[0].team_id].win_count += 1
                runner_up = finalists[0] if finalists[0].team_id != winner[0].team_id else finalists[1]
                counters[runner_up.team_id].final_count += 1

    def _simulate_group_stage(
        self,
        teams: list[TeamConfig],
        rng: np.random.Generator,
    ) -> list[GroupStanding]:
        """Simulate all matches in a group and return standings.

        Args:
            teams: Teams in the group (typically 4).
            rng: Numpy random generator.

        Returns:
            Sorted standings (most points first).
        """
        standings = {t.team_id: GroupStanding(team_id=t.team_id) for t in teams}

        # Round-robin: each team plays every other team
        for i in range(len(teams)):
            for j in range(i + 1, len(teams)):
                home, away = teams[i], teams[j]
                prediction = self._model.predict_match_probabilities(
                    home_elo=home.elo,
                    away_elo=away.elo,
                    home_xg_diff=home.xg_diff,
                    away_xg_diff=away.xg_diff,
                    home_injury=home.injury_score,
                    away_injury=away.injury_score,
                    home_sentiment=home.sentiment_score,
                    away_sentiment=away.sentiment_score,
                )
                result = self._sample_result(prediction, rng)
                goals_home, goals_away = self._sample_scoreline(result, rng)

                # Update standings
                h_stand = standings[home.team_id]
                a_stand = standings[away.team_id]
                h_stand.goals_for += goals_home
                a_stand.goals_for += goals_away
                h_stand.goal_diff += goals_home - goals_away
                a_stand.goal_diff += goals_away - goals_home

                if goals_home > goals_away:
                    h_stand.points += 3
                elif goals_home < goals_away:
                    a_stand.points += 3
                else:
                    h_stand.points += 1
                    a_stand.points += 1

        # Sort by points, then goal difference, then goals for
        sorted_standings = sorted(
            standings.values(),
            key=lambda s: (s.points, s.goal_diff, s.goals_for),
            reverse=True,
        )
        return sorted_standings

    def _simulate_knockout_round(
        self,
        teams: list[TeamConfig],
        rng: np.random.Generator,
    ) -> list[TeamConfig]:
        """Simulate a knockout round (pairs of teams).

        Args:
            teams: Teams in this round (must be even).
            rng: Numpy random generator.

        Returns:
            List of winners.
        """
        winners: list[TeamConfig] = []
        for i in range(0, len(teams), 2):
            home, away = teams[i], teams[i + 1]
            prediction = self._model.predict_match_probabilities(
                home_elo=home.elo,
                away_elo=away.elo,
                home_xg_diff=home.xg_diff,
                away_xg_diff=away.xg_diff,
                home_injury=home.injury_score,
                away_injury=away.injury_score,
                home_sentiment=home.sentiment_score,
                away_sentiment=away.sentiment_score,
            )

            # For knockout: if draw after 90min, 50/50 penalty shootout
            result = self._sample_result(prediction, rng)
            if result == "draw":
                # Penalty shootout — slight Elo advantage
                home_penalty_prob = self._model.predict_match_probabilities(
                    home.elo, away.elo
                ).home_win_prob
                # Adjust toward 50/50 for penalties
                adj_prob = 0.5 + (home_penalty_prob - 0.5) * 0.3
                winner = home if rng.random() < adj_prob else away
            elif result == "home_win":
                winner = home
            else:
                winner = away

            winners.append(winner)

        return winners

    def _sample_result(self, prediction: MatchPrediction, rng: np.random.Generator) -> str:
        """Sample a match result from prediction probabilities."""
        r = rng.random()
        if r < prediction.away_win_prob:
            return "away_win"
        elif r < prediction.away_win_prob + prediction.draw_prob:
            return "draw"
        else:
            return "home_win"

    def _sample_scoreline(self, result: str, rng: np.random.Generator) -> tuple[int, int]:
        """Sample a realistic scoreline given the match result.

        Uses Poisson distribution calibrated to international football averages.
        """
        # Average goals in international football: ~1.3 per team
        avg_goals = 1.3

        if result == "home_win":
            home_goals = max(1, rng.poisson(avg_goals + 0.3))
            away_goals = min(home_goals - 1, rng.poisson(avg_goals - 0.2))
            away_goals = max(0, away_goals)
        elif result == "away_win":
            away_goals = max(1, rng.poisson(avg_goals + 0.3))
            home_goals = min(away_goals - 1, rng.poisson(avg_goals - 0.2))
            home_goals = max(0, home_goals)
        else:  # draw
            base = rng.poisson(avg_goals)
            home_goals = base
            away_goals = base

        return home_goals, away_goals
