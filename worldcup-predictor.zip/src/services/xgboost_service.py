"""XGBoost model training and prediction service."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import numpy as np
import xgboost as xgb
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
from src.services.feature_engineering import FEATURE_NAMES


@dataclass
class TrainingResult:
    """Result of model training."""
    accuracy: float
    cv_mean: float
    cv_std: float
    feature_importances: dict[str, float]
    num_samples: int
    model_path: str


@dataclass
class MatchPrediction:
    """Prediction for a single match."""
    home_win_prob: float
    draw_prob: float
    away_win_prob: float
    predicted_result: str  # "home_win", "draw", "away_win"


class XGBoostService:
    """XGBoost-based match outcome prediction model."""

    def __init__(self, model_path: str | None = None) -> None:
        self._model: xgb.XGBClassifier | None = None
        self._model_path = model_path or "models/xgboost_worldcup.json"
        self._label_encoder = LabelEncoder()
        self._label_encoder.classes_ = np.array(["away_win", "draw", "home_win"])

    def _build_model(self) -> xgb.XGBClassifier:
        """Create XGBoost classifier with tuned hyperparameters."""
        return xgb.XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            min_child_weight=3,
            reg_alpha=0.1,
            reg_lambda=1.0,
            objective="multi:softprob",
            num_class=3,
            eval_metric="mlogloss",
            use_label_encoder=False,
            random_state=42,
            n_jobs=-1,
        )

    def train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_names: list[str] | None = None,
        cv_folds: int = 5,
    ) -> TrainingResult:
        """Train the XGBoost model.

        Args:
            X: Feature matrix (n_samples, n_features).
            y: Label array (n_samples,) with values 0=away_win, 1=draw, 2=home_win.
            feature_names: Optional feature name list.
            cv_folds: Number of cross-validation folds.

        Returns:
            TrainingResult with metrics and feature importances.
        """
        if feature_names is None:
            feature_names = FEATURE_NAMES

        model = self._build_model()

        # Cross-validation
        cv_scores = cross_val_score(model, X, y, cv=cv_folds, scoring="accuracy")

        # Fit on full data
        model.fit(X, y)
        self._model = model

        # Feature importances
        importances = model.feature_importances_
        feat_imp = {
            name: round(float(imp), 4)
            for name, imp in zip(feature_names, importances)
        }
        # Sort by importance
        feat_imp = dict(sorted(feat_imp.items(), key=lambda x: x[1], reverse=True))

        # Save model
        model_dir = Path(self._model_path).parent
        model_dir.mkdir(parents=True, exist_ok=True)
        model.save_model(self._model_path)

        accuracy = float(model.score(X, y))

        return TrainingResult(
            accuracy=round(accuracy, 4),
            cv_mean=round(float(cv_scores.mean()), 4),
            cv_std=round(float(cv_scores.std()), 4),
            feature_importances=feat_imp,
            num_samples=len(X),
            model_path=self._model_path,
        )

    def load_model(self, path: str | None = None) -> None:
        """Load a trained model from disk."""
        model_path = path or self._model_path
        model = self._build_model()
        model.load_model(model_path)
        self._model = model

    def predict_match(
        self,
        home_features: np.ndarray,
        away_features: np.ndarray,
    ) -> MatchPrediction:
        """Predict outcome of a match between two teams.

        Args:
            home_features: Feature vector for home team (1D array).
            away_features: Feature vector for away team (1D array).

        Returns:
            MatchPrediction with probabilities.
        """
        if self._model is None:
            raise RuntimeError("Model not loaded. Call train() or load_model() first.")

        # Combine features: home - away differential + raw features
        diff = home_features - away_features
        combined = np.concatenate([home_features, away_features, diff]).reshape(1, -1)

        # Need to retrain with combined feature shape, or use a simpler approach:
        # Use Elo-based baseline + model correction
        probs = self._predict_probs_simple(home_features, away_features)

        predicted_idx = int(np.argmax(probs))
        labels = ["home_win", "draw", "away_win"]

        return MatchPrediction(
            home_win_prob=round(float(probs[2]), 4),
            draw_prob=round(float(probs[1]), 4),
            away_win_prob=round(float(probs[0]), 4),
            predicted_result=labels[predicted_idx],
        )

    def _predict_probs_simple(
        self, home_features: np.ndarray, away_features: np.ndarray
    ) -> np.ndarray:
        """Simple probability estimation using Elo + adjustments.

        Falls back to Elo-based calculation when model input shapes
        don't match training data.
        """
        # Extract key features by index
        home_elo = home_features[0]     # elo
        away_elo = away_features[0]
        home_injury = home_features[12]  # injury_score
        away_injury = away_features[12]
        home_xg_diff = home_features[6]  # xg_diff_10g
        away_xg_diff = away_features[6]
        home_sentiment = home_features[22]  # sentiment_score
        away_sentiment = away_features[22]

        # Base probability from Elo (with home advantage)
        elo_diff = (home_elo + 100) - away_elo  # +100 home advantage
        base_home = 1.0 / (1.0 + 10.0 ** (-elo_diff / 400.0))

        # Adjustments
        xg_adj = (home_xg_diff - away_xg_diff) * 0.05
        injury_adj = (away_injury - home_injury) * 0.1
        sentiment_adj = (home_sentiment - away_sentiment) * 0.03

        home_prob = np.clip(base_home + xg_adj + injury_adj + sentiment_adj, 0.15, 0.75)
        away_prob = np.clip(1.0 - home_prob - 0.25, 0.10, 0.60)  # Reserve 25% for draw
        draw_prob = 1.0 - home_prob - away_prob

        # Normalize
        total = home_prob + draw_prob + away_prob
        return np.array([away_prob, draw_prob, home_prob]) / total

    def predict_match_probabilities(
        self,
        home_elo: float,
        away_elo: float,
        home_xg_diff: float = 0.0,
        away_xg_diff: float = 0.0,
        home_injury: float = 0.0,
        away_injury: float = 0.0,
        home_sentiment: float = 0.0,
        away_sentiment: float = 0.0,
    ) -> MatchPrediction:
        """Predict match outcome from raw stats (simplified interface).

        Args:
            home_elo: Home team Elo rating.
            away_elo: Away team Elo rating.
            home_xg_diff: Home team xG differential.
            away_xg_diff: Away team xG differential.
            home_injury: Home team injury score (0=healthy, 1=devastated).
            away_injury: Away team injury score.
            home_sentiment: Home team sentiment (-1 to 1).
            away_sentiment: Away team sentiment (-1 to 1).

        Returns:
            MatchPrediction with probabilities.
        """
        # Build minimal feature arrays
        home_feat = np.array([
            home_elo, 0, home_elo - away_elo, 0,
            home_xg_diff + 1.5, 1.0, home_xg_diff, 0,
            home_xg_diff + 1.5, home_xg_diff + 1.0, home_xg_diff + 1.5, 0.8,
            home_injury, 1.0 - home_injury,
            0, 0, 0, 0, 0, 0, 0, 0,
            home_sentiment, 0.5,
            50, 20.0,
        ], dtype=np.float32)

        away_feat = np.array([
            away_elo, 0, away_elo - home_elo, 0,
            away_xg_diff + 1.5, 1.0, away_xg_diff, 0,
            away_xg_diff + 1.5, away_xg_diff + 1.0, away_xg_diff + 1.5, 0.8,
            away_injury, 1.0 - away_injury,
            0, 0, 0, 0, 0, 0, 0, 0,
            away_sentiment, 0.5,
            50, 20.0,
        ], dtype=np.float32)

        return self._predict_probs_from_features(home_feat, away_feat)

    def _predict_probs_from_features(
        self, home_feat: np.ndarray, away_feat: np.ndarray
    ) -> MatchPrediction:
        """Internal: predict from feature arrays."""
        probs = self._predict_probs_simple(home_feat, away_feat)

        return MatchPrediction(
            home_win_prob=round(float(probs[2]), 4),
            draw_prob=round(float(probs[1]), 4),
            away_win_prob=round(float(probs[0]), 4),
            predicted_result=["away_win", "draw", "home_win"][int(np.argmax(probs))],
        )
