"""Real-time update scheduler — runs every 15 minutes."""
from __future__ import annotations
import asyncio
import logging
import random
from datetime import datetime

logger = logging.getLogger(__name__)


class UpdateScheduler:
    """Periodically updates odds, news sentiment, injuries, and recalculates probabilities."""

    def __init__(self, interval_minutes: int = 15) -> None:
        self._interval = interval_minutes * 60
        self._running = False
        self._task: asyncio.Task | None = None
        self._last_update: datetime | None = None
        self._update_count = 0

    async def start(self) -> None:
        """Start the background update loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        logger.info(f"Scheduler started — updating every {self._interval // 60} minutes")

    async def stop(self) -> None:
        """Stop the background update loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Scheduler stopped")

    async def _loop(self) -> None:
        """Main update loop."""
        while self._running:
            try:
                await self._run_update_cycle()
            except Exception as e:
                logger.error(f"Update cycle failed: {e}")
            await asyncio.sleep(self._interval)

    async def _run_update_cycle(self) -> None:
        """Execute one full update cycle."""
        logger.info("Starting update cycle...")
        start = datetime.utcnow()

        # Step 1: Update odds (simulate market movement)
        await self._update_odds()

        # Step 2: Update news sentiment
        await self._update_sentiment()

        # Step 3: Update injury scores
        await self._update_injuries()

        # Step 4: Recalculate probabilities via Monte Carlo
        await self._recalculate_probabilities()

        self._last_update = datetime.utcnow()
        self._update_count += 1
        elapsed = (self._last_update - start).total_seconds()
        logger.info(f"Update cycle #{self._update_count} completed in {elapsed:.1f}s")

    async def _update_odds(self) -> None:
        """Simulate odds market movement."""
        from src.infrastructure.database.session import async_session_factory
        from src.infrastructure.database.models import OddsModel
        from sqlalchemy import select

        async with async_session_factory() as session:
            result = await session.execute(select(OddsModel))
            odds = result.scalars().all()

            for o in odds:
                # Random walk: ±3% per cycle
                change = random.gauss(0, 0.015)
                o.odds = max(1.01, round(o.odds * (1 + change), 2))
                o.implied_prob = round(1.0 / o.odds, 4)

            await session.commit()
        logger.info(f"Updated {len(odds)} odds records")

    async def _update_sentiment(self) -> None:
        """Simulate sentiment fluctuation."""
        from src.infrastructure.database.session import async_session_factory
        from src.infrastructure.database.models import TeamModel
        from sqlalchemy import select

        async with async_session_factory() as session:
            result = await session.execute(select(TeamModel))
            teams = result.scalars().all()

            for t in teams:
                # Mean-reverting sentiment: drift toward 0 with noise
                drift = -t.sentiment * 0.1
                noise = random.gauss(0, 0.05)
                t.sentiment = round(max(-1.0, min(1.0, t.sentiment + drift + noise)), 3)

            await session.commit()
        logger.info(f"Updated sentiment for {len(teams)} teams")

    async def _update_injuries(self) -> None:
        """Simulate injury score changes."""
        from src.infrastructure.database.session import async_session_factory
        from src.infrastructure.database.models import TeamModel, PlayerModel
        from sqlalchemy import select

        async with async_session_factory() as session:
            # Random injury events
            result = await session.execute(select(PlayerModel))
            players = result.scalars().all()

            injured_count = 0
            for p in players:
                if p.injury:
                    # 15% chance to recover
                    if random.random() < 0.15:
                        p.injury = False
                        p.form_score = max(0.3, p.form_score - 0.1)
                else:
                    # 3% chance to get injured
                    if random.random() < 0.03:
                        p.injury = True
                        injured_count += 1

            # Recalculate team injury scores
            teams_result = await session.execute(select(TeamModel))
            teams = teams_result.scalars().all()

            for t in teams:
                team_players_result = await session.execute(
                    select(PlayerModel).where(PlayerModel.team_id == t.id)
                )
                team_players = team_players_result.scalars().all()
                if team_players:
                    injured = sum(1 for p in team_players if p.injury)
                    t.injury_score = round(injured / len(team_players), 3)

            await session.commit()
        logger.info(f"Processed injuries: {injured_count} new, updated all team scores")

    async def _recalculate_probabilities(self) -> None:
        """Run Monte Carlo simulation and update probabilities."""
        from src.infrastructure.database.session import async_session_factory
        from src.infrastructure.database.models import TeamModel, PredictionModel
        from src.services.monte_carlo_service import MonteCarloService, TeamConfig
        from src.services.xgboost_service import XGBoostService
        from sqlalchemy import select

        async with async_session_factory() as session:
            result = await session.execute(select(TeamModel))
            db_teams = result.scalars().all()

            # Build team configs
            team_configs = [
                TeamConfig(
                    team_id=t.id, code=t.code, name=t.name,
                    group=t.group_name or "A", elo=t.elo,
                    xg_diff=t.xg - t.xga,
                    injury_score=t.injury_score,
                    sentiment_score=t.sentiment,
                )
                for t in db_teams
            ]

            # Run simulation
            xgb = XGBoostService()
            mc = MonteCarloService(xgb)
            tournament = mc.simulate_tournament(team_configs, num_simulations=50_000, seed=None)

            # Update predictions table
            from sqlalchemy import delete
            await session.execute(delete(PredictionModel))

            for sim in tournament.sorted_by_win_prob:
                # Update team win_probability
                team = next((t for t in db_teams if t.id == sim.team_id), None)
                if team:
                    team.win_probability = round(sim.win_probability, 4)

                pred = PredictionModel(
                    team=sim.team_name,
                    team_cn=team.name_cn if team else sim.team_name,
                    win_probability=round(sim.win_probability, 4),
                    group_stage_prob=round(sim.r16_probability, 4),
                    round_of_16_prob=round(sim.r16_probability, 4),
                    quarter_final_prob=round(sim.quarter_probability, 4),
                    semi_final_prob=round(sim.semi_probability, 4),
                    final_prob=round(sim.final_probability, 4),
                    simulations_count=50_000,
                )
                session.add(pred)

            await session.commit()
        logger.info(f"Recalculated probabilities for {len(db_teams)} teams")

    @property
    def status(self) -> dict:
        return {
            "running": self._running,
            "last_update": self._last_update.isoformat() if self._last_update else None,
            "update_count": self._update_count,
            "interval_minutes": self._interval // 60,
        }
