"""Feature engineering pipeline — aggregates all signals into ML feature vectors."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from src.services.elo_service import EloService
from src.services.xg_service import XGService, XGFeatures
from src.services.injury_service import InjuryService, InjuryEntry
from src.services.odds_service import OddsService, AggregatedOdds, OddsMovementAnalysis
from src.services.sentiment_service import SentimentResult


# Feature names in order — must match model training
FEATURE_NAMES: list[str] = [
    "elo",
    "elo_opponent",
    "elo_diff",
    "elo_win_prob",
    "xg_10g",
    "xga_10g",
    "xg_diff_10g",
    "xg_trend",
    "xg_home",
    "xg_away",
    "xg_vs_strong",
    "xg_conceded_rate",
    "injury_score",
    "availability_factor",
    "odds_home_prob",
    "odds_draw_prob",
    "odds_away_prob",
    "odds_overround",
    "odds_confidence",
    "odds_home_shift",
    "odds_away_shift",
    "odds_steam_move",
    "sentiment_score",
    "sentiment_confidence",
    "fifa_ranking",
    "squad_value_log",
]


@dataclass
class TeamFeatureVector:
    """Complete feature vector for one team in one match context."""
    team_id: int
    team_code: str
    features: dict[str, float]

    def to_array(self) -> np.ndarray:
        """Convert to numpy array in FEATURE_NAMES order."""
        return np.array([self.features.get(f, 0.0) for f in FEATURE_NAMES], dtype=np.float32)


class FeatureEngineering:
    """Aggregates all domain services into ML-ready feature vectors."""

    def __init__(
        self,
        elo_service: EloService,
        xg_service: XGService,
        injury_service: InjuryService,
        odds_service: OddsService,
    ) -> None:
        self._elo = elo_service
        self._xg = xg_service
        self._injury = injury_service
        self._odds = odds_service

    def build_feature_vector(
        self,
        team_elo: float,
        opponent_elo: float,
        xg_features: XGFeatures,
        injury_entries: list[InjuryEntry],
        squad: list[dict],
        odds: AggregatedOdds | None = None,
        movement: OddsMovementAnalysis | None = None,
        sentiment: SentimentResult | None = None,
        fifa_ranking: int = 50,
        squad_market_value: float = 0.0,
    ) -> dict[str, float]:
        """Build a complete feature vector for a team.

        Args:
            team_elo: Team's current Elo rating.
            opponent_elo: Opponent's Elo rating.
            xg_features: XG feature set from XGService.
            injury_entries: Current injury list.
            squad: Full squad for injury report.
            odds: Aggregated odds (optional).
            movement: Odds movement analysis (optional).
            sentiment: Sentiment analysis result (optional).
            fifa_ranking: FIFA ranking position.
            squad_market_value: Total squad market value in EUR.

        Returns:
            Dict mapping feature name to value.
        """
        # Elo features
        elo_win_prob = self._elo.win_probability(team_elo, opponent_elo)

        # Injury features
        injury_report = self._injury.compute_injury_report(squad, injury_entries)
        availability = self._injury.availability_factor(injury_report)

        # Odds features
        if odds:
            odds_feats = self._odds.odds_to_features(odds, movement)
        else:
            odds_feats = {
                "odds_home_prob": 0.0, "odds_draw_prob": 0.0, "odds_away_prob": 0.0,
                "odds_overround": 0.0, "odds_confidence": 0.0,
                "odds_home_shift": 0.0, "odds_away_shift": 0.0, "odds_steam_move": 0.0,
            }

        # Sentiment features
        sent_score = sentiment.score if sentiment else 0.0
        sent_conf = sentiment.confidence if sentiment else 0.0

        # Squad value (log-transformed for normalization)
        squad_val_log = float(np.log1p(squad_market_value)) if squad_market_value > 0 else 0.0

        features = {
            "elo": team_elo,
            "elo_opponent": opponent_elo,
            "elo_diff": team_elo - opponent_elo,
            "elo_win_prob": round(elo_win_prob, 4),
            "xg_10g": xg_features.xg_10g,
            "xga_10g": xg_features.xga_10g,
            "xg_diff_10g": xg_features.xg_diff_10g,
            "xg_trend": xg_features.xg_trend,
            "xg_home": xg_features.xg_home,
            "xg_away": xg_features.xg_away,
            "xg_vs_strong": xg_features.xg_vs_strong,
            "xg_conceded_rate": xg_features.xg_conceded_rate,
            "injury_score": injury_report.injury_score,
            "availability_factor": availability,
            **odds_feats,
            "sentiment_score": sent_score,
            "sentiment_confidence": sent_conf,
            "fifa_ranking": float(fifa_ranking),
            "squad_value_log": round(squad_val_log, 4),
        }

        return features
