"""Elo rating system for national teams."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class MatchImportance(str, Enum):
    FRIENDLY = "friendly"
    QUALIFIER = "qualifier"
    GROUP_STAGE = "group_stage"
    KNOCKOUT = "knockout"
    FINAL = "final"


# K-factor lookup by match importance
_K_FACTORS: dict[MatchImportance, float] = {
    MatchImportance.FRIENDLY: 30.0,
    MatchImportance.QUALIFIER: 40.0,
    MatchImportance.GROUP_STAGE: 50.0,
    MatchImportance.KNOCKOUT: 60.0,
    MatchImportance.FINAL: 70.0,
}

HOME_ADVANTAGE_ELO = 100.0
NEUTRAL_VENUE_ELO = 0.0


@dataclass
class EloUpdateResult:
    """Result of an Elo rating update."""
    new_home_elo: float
    new_away_elo: float
    expected_home_score: float
    expected_away_score: float
    k_factor: float


class EloService:
    """Implements the Elo rating system for international football."""

    def calculate_expected_score(self, team_a_elo: float, team_b_elo: float) -> float:
        """Expected score for team A against team B.

        Args:
            team_a_elo: Team A's current Elo rating.
            team_b_elo: Team B's current Elo rating.

        Returns:
            Expected score in [0, 1] — probability of team A winning.
        """
        return 1.0 / (1.0 + 10.0 ** ((team_b_elo - team_a_elo) / 400.0))

    def calculate_k_factor(self, importance: MatchImportance) -> float:
        """Get the K-factor for a match of given importance."""
        return _K_FACTORS.get(importance, 40.0)

    def update_ratings(
        self,
        home_elo: float,
        away_elo: float,
        home_goals: int,
        away_goals: int,
        importance: MatchImportance = MatchImportance.GROUP_STAGE,
        is_neutral: bool = False,
    ) -> EloUpdateResult:
        """Update Elo ratings after a match.

        Args:
            home_elo: Home team's current Elo.
            away_elo: Away team's current Elo.
            home_goals: Goals scored by home team.
            away_goals: Goals scored by away team.
            importance: Match importance level.
            is_neutral: Whether the match is at a neutral venue.

        Returns:
            EloUpdateResult with new ratings and intermediate values.
        """
        # Adjust for home advantage
        home_adj = home_elo + (NEUTRAL_VENUE_ELO if is_neutral else HOME_ADVANTAGE_ELO)

        # Expected scores
        expected_home = self.calculate_expected_score(home_adj, away_elo)
        expected_away = 1.0 - expected_home

        # Actual scores (1 for win, 0.5 for draw, 0 for loss)
        if home_goals > away_goals:
            actual_home, actual_away = 1.0, 0.0
        elif home_goals < away_goals:
            actual_home, actual_away = 0.0, 1.0
        else:
            actual_home, actual_away = 0.5, 0.5

        # Goal difference multiplier (capped at 4)
        goal_diff = abs(home_goals - away_goals)
        goal_multiplier = 1.0 if goal_diff <= 1 else (1.0 + (goal_diff - 1) * 0.25)
        goal_multiplier = min(goal_multiplier, 2.0)

        k = self.calculate_k_factor(importance) * goal_multiplier

        # Update ratings
        new_home = round(home_elo + k * (actual_home - expected_home), 1)
        new_away = round(away_elo + k * (actual_away - expected_away), 1)

        return EloUpdateResult(
            new_home_elo=new_home,
            new_away_elo=new_away,
            expected_home_score=round(expected_home, 4),
            expected_away_score=round(expected_away, 4),
            k_factor=round(k, 1),
        )

    def win_probability(self, team_elo: float, opponent_elo: float, is_neutral: bool = True) -> float:
        """Calculate win probability for a team against an opponent.

        Args:
            team_elo: Team's Elo rating.
            opponent_elo: Opponent's Elo rating.
            is_neutral: Whether the match is at a neutral venue.

        Returns:
            Win probability in [0, 1].
        """
        adj = team_elo if is_neutral else team_elo + HOME_ADVANTAGE_ELO
        return self.calculate_expected_score(adj, opponent_elo)
