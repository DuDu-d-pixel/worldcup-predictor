"""Team harmony NLP sentiment analysis service."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
import math


@dataclass
class SentimentResult:
    """Result of sentiment analysis for a team."""
    score: float           # -1.0 (negative) to 1.0 (positive)
    confidence: float      # 0.0 to 1.0
    sample_size: int       # Number of texts analyzed
    source_breakdown: dict[str, float]  # Score per source


class SentimentService:
    """Analyzes team morale/harmony via news and social media sentiment.

    Uses multilingual BERT for sentiment classification with exponential
    time-decay weighting for recency.
    """

    def __init__(self, model_name: str = "nlptown/bert-base-multilingual-uncased-sentiment") -> None:
        self._model_name = model_name
        self._pipeline = None

    def _get_pipeline(self):
        """Lazy-load the transformers pipeline."""
        if self._pipeline is None:
            from transformers import pipeline
            self._pipeline = pipeline(
                "sentiment-analysis",
                model=self._model_name,
                truncation=True,
                max_length=512,
            )
        return self._pipeline

    def _time_decay_weight(self, published_at: datetime, half_life_days: float = 7.0) -> float:
        """Exponential decay weight based on article age.

        Args:
            published_at: When the article was published.
            half_life_days: Days until weight halves.

        Returns:
            Weight in (0, 1].
        """
        age_days = max((datetime.utcnow() - published_at).total_seconds() / 86400, 0)
        return math.exp(-0.693 * age_days / half_life_days)  # ln(2) ≈ 0.693

    def _stars_to_score(self, label: str) -> float:
        """Convert model label (e.g., '5 stars') to [-1, 1] score."""
        try:
            stars = int(label.split()[0])
            return (stars - 3) / 2.0  # 1→-1, 2→-0.5, 3→0, 4→0.5, 5→1
        except (ValueError, IndexError):
            return 0.0

    def analyze_texts(
        self,
        texts: list[dict],  # [{text: str, source: str, published_at: datetime}]
        batch_size: int = 16,
    ) -> SentimentResult:
        """Analyze sentiment of a list of texts with time-decay weighting.

        Args:
            texts: List of dicts with text, source, and published_at.
            batch_size: Batch size for model inference.

        Returns:
            SentimentResult with aggregated score.
        """
        if not texts:
            return SentimentResult(score=0.0, confidence=0.0, sample_size=0, source_breakdown={})

        pipe = self._get_pipeline()

        # Prepare texts and weights
        raw_texts = [t["text"] for t in texts]
        weights = [self._time_decay_weight(t["published_at"]) for t in texts]
        sources = [t.get("source", "unknown") for t in texts]

        # Run inference in batches
        all_scores: list[float] = []
        all_confidences: list[float] = []
        for i in range(0, len(raw_texts), batch_size):
            batch = raw_texts[i:i + batch_size]
            results = pipe(batch)
            for r in results:
                all_scores.append(self._stars_to_score(r["label"]))
                all_confidences.append(r["score"])

        # Weighted average
        total_weight = sum(weights)
        if total_weight == 0:
            return SentimentResult(score=0.0, confidence=0.0, sample_size=0, source_breakdown={})

        weighted_score = sum(s * w for s, w in zip(all_scores, weights)) / total_weight
        weighted_confidence = sum(c * w for c, w in zip(all_confidences, weights)) / total_weight

        # Source breakdown
        source_scores: dict[str, list[tuple[float, float]]] = {}
        for s, w, src in zip(all_scores, weights, sources):
            source_scores.setdefault(src, []).append((s, w))

        source_breakdown: dict[str, float] = {}
        for src, pairs in source_scores.items():
            sw = sum(s * w for s, w in pairs)
            tw = sum(w for _, w in pairs)
            source_breakdown[src] = round(sw / tw, 4) if tw > 0 else 0.0

        return SentimentResult(
            score=round(weighted_score, 4),
            confidence=round(weighted_confidence, 4),
            sample_size=len(texts),
            source_breakdown=source_breakdown,
        )

    async def analyze_team_sentiment(
        self,
        team_id: int,
        texts: list[dict] | None = None,
    ) -> float:
        """Async interface for team sentiment analysis.

        Args:
            team_id: Team ID.
            texts: Pre-fetched texts (in production, fetched from DB).

        Returns:
            Sentiment score in [-1, 1].
        """
        if texts is None:
            return 0.0  # Neutral default when no data
        result = self.analyze_texts(texts)
        return result.score
