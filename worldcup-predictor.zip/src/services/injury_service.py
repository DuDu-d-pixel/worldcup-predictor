"""Injury scoring system for national teams."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from src.domain.value_objects.injury_report import InjuryReport


# Position weights: how much a position loss impacts team performance
_POSITION_WEIGHTS: dict[str, float] = {
    "GK": 1.2,   # Goalkeeper — hard to replace
    "DEF": 1.0,
    "MID": 1.1,   # Midfield control is critical
    "FWD": 1.3,   # Goal scorers are hardest to replace
}


@dataclass
class InjuryEntry:
    """Single player injury record."""
    player_name: str
    position: str
    market_value: float
    injury_type: str
    expected_return: date | None
    recent_appearances: int = 0  # out of last 10 matches


class InjuryService:
    """Computes team injury severity scores."""

    def compute_injury_report(
        self,
        squad: list[dict],          # Full squad: [{name, position, market_value, appearances}]
        injuries: list[InjuryEntry], # Current injuries
        today: date | None = None,
    ) -> InjuryReport:
        """Compute an aggregated injury report for a team.

        Args:
            squad: Full squad list with player metadata.
            injuries: Currently injured players.
            today: Reference date (defaults to today).

        Returns:
            InjuryReport value object.
        """
        if today is None:
            today = date.today()

        total_players = len(squad)
        if total_players == 0:
            return InjuryReport()

        total_value = sum(p.get("market_value", 0.0) for p in squad)

        # Compute weighted injury cost
        injured_value_weighted = 0.0
        active_injuries = 0

        for inj in injuries:
            # Only count active injuries
            if inj.expected_return and inj.expected_return <= today:
                continue  # Player expected back
            active_injuries += 1

            pos_weight = _POSITION_WEIGHTS.get(inj.position, 1.0)
            # Appearance-based importance: regular starters matter more
            appearance_ratio = min(inj.recent_appearances / 10.0, 1.0)
            importance = 0.5 + 0.5 * appearance_ratio  # [0.5, 1.0]

            injured_value_weighted += inj.market_value * pos_weight * importance

        # Injury score: 0 = fully healthy, 1 = devastated
        if total_value > 0:
            raw_score = injured_value_weighted / total_value
            # Normalize — losing 30% of weighted value ≈ score of 1.0
            injury_score = min(raw_score / 0.3, 1.0)
        else:
            injury_score = 0.0

        return InjuryReport(
            total_players=total_players,
            injured_players=active_injuries,
            injured_market_value=round(injured_value_weighted, 2),
            total_market_value=round(total_value, 2),
            injury_score=round(injury_score, 4),
        )

    def availability_factor(self, report: InjuryReport) -> float:
        """Convert injury report to a multiplier for match prediction.

        Returns:
            Factor in [0.7, 1.0] — 1.0 for fully healthy, ~0.7 for heavily injured.
        """
        return round(1.0 - 0.3 * report.injury_score, 4)
