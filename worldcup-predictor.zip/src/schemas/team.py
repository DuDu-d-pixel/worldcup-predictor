"""Team schemas."""
from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime


class TeamBase(BaseModel):
    name: str
    code: str = Field(..., max_length=3, min_length=3)
    fifa_ranking: int | None = None
    group: str | None = None


class TeamResponse(TeamBase):
    id: int
    elo_rating: float
    squad_market_value: float
    elo_tier: str = ""
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}

    @classmethod
    def model_validate(cls, obj, **kwargs):
        """Map ORM model fields and compute elo_tier."""
        data = {
            "id": obj.id,
            "name": obj.name,
            "code": obj.code,
            "fifa_ranking": obj.fifa_ranking,
            "group": obj.group_name,
            "elo_rating": obj.elo_rating,
            "squad_market_value": obj.squad_market_value,
            "created_at": obj.created_at,
            "updated_at": obj.updated_at,
        }
        elo = obj.elo_rating or 1500
        if elo >= 2000:
            data["elo_tier"] = "elite"
        elif elo >= 1800:
            data["elo_tier"] = "strong"
        elif elo >= 1600:
            data["elo_tier"] = "average"
        else:
            data["elo_tier"] = "weak"
        return super().model_validate(data, **kwargs)


class TeamListResponse(BaseModel):
    teams: list[TeamResponse]
    total: int


class TeamDetailResponse(TeamResponse):
    injury_score: float | None = None
    sentiment_score: float | None = None
    xg_stats: dict | None = None
