"""Odds schemas."""
from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime


class OddsSnapshotResponse(BaseModel):
    bookmaker: str
    home_win_odds: float
    draw_odds: float
    away_win_odds: float
    home_implied_prob: float
    draw_implied_prob: float
    away_implied_prob: float
    overround: float
    snapshot_time: datetime

    model_config = {"from_attributes": True}


class OddsHistoryResponse(BaseModel):
    match_id: int
    snapshots: list[OddsSnapshotResponse]
    aggregated_probs: dict[str, float]
    movement: dict[str, float] | None = None


class OddsRefreshRequest(BaseModel):
    match_ids: list[int] | None = None
    force: bool = False
