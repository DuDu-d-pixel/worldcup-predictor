"""Simulation schemas."""
from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime


class SimulationTeamResult(BaseModel):
    team_id: int
    team_code: str
    team_name: str
    win_probability: float
    group_stage_prob: float
    round_of_16_prob: float
    quarter_final_prob: float
    semi_final_prob: float
    final_prob: float


class SimulationStatusResponse(BaseModel):
    task_id: str
    status: str  # "running", "completed", "failed"
    progress: float = Field(default=0.0, ge=0, le=1)
    result: list[SimulationTeamResult] | None = None
    total_simulations: int = 0
    model_version: str = "1.0"
    created_at: datetime = Field(default_factory=datetime.utcnow)
