"""Prediction schemas."""
from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime


class TeamPrediction(BaseModel):
    team_id: int
    team_code: str
    team_name: str
    group: str | None = None
    elo_rating: float
    win_probability: float = Field(..., ge=0, le=1)
    group_stage_prob: float = Field(..., ge=0, le=1)
    round_of_16_prob: float = Field(..., ge=0, le=1)
    quarter_final_prob: float = Field(..., ge=0, le=1)
    semi_final_prob: float = Field(..., ge=0, le=1)
    final_prob: float = Field(..., ge=0, le=1)
    model_version: str = "1.0"


class PredictionListResponse(BaseModel):
    predictions: list[TeamPrediction]
    total_simulations: int
    model_version: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MatchPredictionRequest(BaseModel):
    home_team_code: str = Field(..., min_length=3, max_length=3)
    away_team_code: str = Field(..., min_length=3, max_length=3)
    is_neutral: bool = True


class MatchPredictionResponse(BaseModel):
    home_team: str
    away_team: str
    home_win_prob: float
    draw_prob: float
    away_win_prob: float
    predicted_result: str


class SimulationRequest(BaseModel):
    num_simulations: int = Field(default=100_000, ge=1000, le=1_000_000)
    seed: int | None = 42


class SimulationResponse(BaseModel):
    message: str
    task_id: str
    status: str = "running"
