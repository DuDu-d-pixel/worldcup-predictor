"""Redis cache adapter — gracefully degrades if Redis is unavailable."""
from __future__ import annotations
import json
import logging
from typing import Any
from src.config import get_settings

logger = logging.getLogger(__name__)


class RedisCache:
    """Thin async wrapper around Redis for caching.
    Falls back to no-op if Redis is unreachable.
    """

    def __init__(self) -> None:
        self._redis = None
        self._ttl = get_settings().cache_ttl_seconds
        try:
            import redis.asyncio as redis_mod
            self._redis = redis_mod.from_url(get_settings().redis_url, decode_responses=True)
        except Exception:
            logger.warning("Redis not available — caching disabled")

    async def get(self, key: str) -> Any | None:
        if self._redis is None:
            return None
        try:
            raw = await self._redis.get(key)
            return json.loads(raw) if raw else None
        except Exception:
            return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        if self._redis is None:
            return
        try:
            data = json.dumps(value, default=str)
            await self._redis.set(key, data, ex=ttl or self._ttl)
        except Exception:
            pass

    async def delete(self, key: str) -> None:
        if self._redis is None:
            return
        try:
            await self._redis.delete(key)
        except Exception:
            pass

    async def exists(self, key: str) -> bool:
        if self._redis is None:
            return False
        try:
            return bool(await self._redis.exists(key))
        except Exception:
            return False

    async def close(self) -> None:
        if self._redis is not None:
            try:
                await self._redis.close()
            except Exception:
                pass
