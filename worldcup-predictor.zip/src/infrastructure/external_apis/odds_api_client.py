"""Betting odds API client."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential
from src.config import get_settings
from src.domain.value_objects.odds import OddsSnapshot


@dataclass
class RawOddsData:
    """Raw odds from the API."""
    match_id: str
    home_team: str
    away_team: str
    bookmakers: list[dict[str, Any]]
    commence_time: str


class OddsAPIClient:
    """Client for fetching betting odds from external API (e.g., the-odds-api.com)."""

    def __init__(self) -> None:
        settings = get_settings()
        self._api_key = settings.odds_api_key
        self._base_url = settings.odds_api_base_url
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=30.0,
            params={"apiKey": self._api_key},
        )

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    async def fetch_odds(
        self,
        sport: str = "soccer_fifa_world_cup",
        regions: str = "eu,uk",
        markets: str = "h2h",
    ) -> list[RawOddsData]:
        """Fetch current odds for upcoming matches.

        Args:
            sport: Sport key.
            regions: Bookmaker regions.
            markets: Market types.

        Returns:
            List of RawOddsData.
        """
        response = await self._client.get(
            f"/sports/{sport}/odds",
            params={"regions": regions, "markets": markets},
        )
        response.raise_for_status()
        data = response.json()

        results: list[RawOddsData] = []
        for event in data:
            bookmakers = []
            for bm in event.get("bookmakers", []):
                h2h_market = next(
                    (m for m in bm.get("markets", []) if m["key"] == "h2h"), None
                )
                if h2h_market:
                    outcomes = {o["name"]: o["price"] for o in h2h_market["outcomes"]}
                    bookmakers.append({
                        "name": bm["key"],
                        "home_win": outcomes.get(event["home_team"], 0),
                        "draw": outcomes.get("Draw", 0),
                        "away_win": outcomes.get(event["away_team"], 0),
                    })

            results.append(RawOddsData(
                match_id=event.get("id", ""),
                home_team=event.get("home_team", ""),
                away_team=event.get("away_team", ""),
                bookmakers=bookmakers,
                commence_time=event.get("commence_time", ""),
            ))

        return results

    def to_snapshots(self, raw: RawOddsData) -> list[OddsSnapshot]:
        """Convert raw API data to domain OddsSnapshot objects."""
        snapshots: list[OddsSnapshot] = []
        for bm in raw.bookmakers:
            if bm["home_win"] > 0 and bm["draw"] > 0 and bm["away_win"] > 0:
                snapshots.append(OddsSnapshot(
                    bookmaker=bm["name"],
                    home_win=bm["home_win"],
                    draw=bm["draw"],
                    away_win=bm["away_win"],
                    timestamp=raw.commence_time or datetime.utcnow().isoformat(),
                ))
        return snapshots

    async def close(self) -> None:
        await self._client.aclose()
