"""Transfermarkt injury data scraping client."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import httpx
from bs4 import BeautifulSoup
from tenacity import retry, stop_after_attempt, wait_exponential


@dataclass
class InjuryData:
    """Injury data from Transfermarkt."""
    player_name: str
    team_name: str
    position: str
    injury_type: str
    market_value: float
    expected_return: str | None


class TransfermarktClient:
    """Client for scraping injury data from Transfermarkt."""

    BASE_URL = "https://www.transfermarkt.com"

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0.0.0 Safari/537.36",
            },
            follow_redirects=True,
        )

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=15))
    async def fetch_team_injuries(self, team_slug: str) -> list[InjuryData]:
        """Fetch current injuries for a national team.

        Args:
            team_slug: Transfermarkt team URL slug (e.g., "brazil/startseite/verein/3435").

        Returns:
            List of InjuryData for currently injured players.
        """
        url = f"{self.BASE_URL}/{team_slug}/verletzungen/verein/"
        response = await self._client.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "lxml")
        table = soup.find("table", {"class": "items"})

        injuries: list[InjuryData] = []
        if table:
            rows = table.find("tbody").find_all("tr", {"class": ["odd", "even"]})
            for row in rows:
                cells = row.find_all("td")
                if len(cells) >= 6:
                    try:
                        name = cells[1].text.strip()
                        position = cells[2].text.strip()
                        injury = cells[3].text.strip()
                        market_val_str = cells[4].text.strip().replace("€", "").replace("m", "").replace(",", ".")
                        market_value = float(market_val_str) * 1_000_000 if market_val_str else 0.0
                        return_date = cells[5].text.strip() if len(cells) > 5 else None

                        injuries.append(InjuryData(
                            player_name=name,
                            team_name=team_slug.split("/")[0],
                            position=position,
                            injury_type=injury,
                            market_value=market_value,
                            expected_return=return_date if return_date and return_date != "?" else None,
                        ))
                    except (ValueError, IndexError):
                        continue

        return injuries

    async def close(self) -> None:
        await self._client.aclose()
