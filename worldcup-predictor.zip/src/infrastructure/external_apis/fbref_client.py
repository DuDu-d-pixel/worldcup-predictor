"""FBref data scraping client."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import httpx
from bs4 import BeautifulSoup
from tenacity import retry, stop_after_attempt, wait_exponential


@dataclass
class TeamXGData:
    """xG data scraped from FBref for a team."""
    team_name: str
    matches: list[dict[str, Any]]  # [{date, opponent, xg_for, xg_against, venue}]


class FBrefClient:
    """Client for scraping xG data from FBref.com."""

    BASE_URL = "https://fbref.com"

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0.0.0 Safari/537.36",
            },
            follow_redirects=True,
        )

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=15))
    async def fetch_team_match_logs(
        self,
        team_url: str,
        season: str = "2025-2026",
    ) -> TeamXGData:
        """Scrape match logs with xG data for a team.

        Args:
            team_url: FBref team URL path (e.g., "/en/squads/...").
            season: Season string.

        Returns:
            TeamXGData with per-match xG values.
        """
        url = f"{self.BASE_URL}{team_url}/matchlogs/all_comps/shooting/{season}"
        response = await self._client.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "lxml")
        table = soup.find("table", {"id": "matchlogs_for"})

        matches: list[dict[str, Any]] = []
        if table:
            rows = table.find("tbody").find_all("tr") if table.find("tbody") else []
            for row in rows:
                cells = row.find_all("td")
                if len(cells) >= 10:
                    try:
                        matches.append({
                            "date": cells[0].text.strip(),
                            "opponent": cells[5].text.strip(),
                            "xg_for": float(cells[7].text.strip()) if cells[7].text.strip() else None,
                            "xg_against": float(cells[8].text.strip()) if cells[8].text.strip() else None,
                            "venue": cells[4].text.strip(),
                        })
                    except (ValueError, IndexError):
                        continue

        return TeamXGData(team_name=team_url.split("/")[-1], matches=matches)

    async def close(self) -> None:
        await self._client.aclose()
