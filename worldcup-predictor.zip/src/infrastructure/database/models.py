"""SQLAlchemy ORM models — simplified 4-table schema."""
from __future__ import annotations
from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, func
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class TeamModel(Base):
    __tablename__ = "teams"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), nullable=False)
    name_cn = Column(String(50), default="")
    code = Column(String(3), nullable=False, unique=True, index=True)
    group_name = Column(String(1))
    elo = Column(Float, default=1500.0)
    xg = Column(Float, default=0.0)
    xga = Column(Float, default=0.0)
    sentiment = Column(Float, default=0.0)
    injury_score = Column(Float, default=0.0)
    win_probability = Column(Float, default=0.0)
    squad_value = Column(Float, default=0.0)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class PlayerModel(Base):
    __tablename__ = "players"

    id = Column(Integer, primary_key=True, autoincrement=True)
    team_id = Column(Integer, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    position = Column(String(10))
    market_value = Column(Float, default=0.0)
    form_score = Column(Float, default=0.5)
    injury = Column(Boolean, default=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class OddsModel(Base):
    __tablename__ = "odds"

    id = Column(Integer, primary_key=True, autoincrement=True)
    bookmaker = Column(String(50), nullable=False)
    team = Column(String(50), nullable=False, index=True)
    odds = Column(Float, nullable=False)
    implied_prob = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MatchModel(Base):
    __tablename__ = "matches"

    id = Column(Integer, primary_key=True, autoincrement=True)
    home_team = Column(String(50), nullable=False, index=True)
    away_team = Column(String(50), nullable=False, index=True)
    home_team_cn = Column(String(50), default="")
    away_team_cn = Column(String(50), default="")
    match_date = Column(DateTime(timezone=True), nullable=False)
    group_name = Column(String(1))
    match_type = Column(String(20), default="group")  # group, round_of_16, quarter, semi, final
    tournament = Column(String(100), default="FIFA World Cup 2026")
    home_score = Column(Integer, nullable=True)
    away_score = Column(Integer, nullable=True)
    home_xg = Column(Float, nullable=True)
    away_xg = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PredictionModel(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    team = Column(String(50), nullable=False, unique=True, index=True)
    team_cn = Column(String(50), default="")
    win_probability = Column(Float, default=0.0)
    group_stage_prob = Column(Float, default=0.0)
    round_of_16_prob = Column(Float, default=0.0)
    quarter_final_prob = Column(Float, default=0.0)
    semi_final_prob = Column(Float, default=0.0)
    final_prob = Column(Float, default=0.0)
    simulations_count = Column(Integer, default=100000)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
