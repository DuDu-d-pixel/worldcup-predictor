"""NLP sentiment analysis pipeline infrastructure."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass
class SentimentOutput:
    """Raw output from sentiment pipeline."""
    label: str
    score: float


class SentimentPipeline:
    """Wraps the transformers sentiment pipeline with caching and batching."""

    def __init__(self, model_name: str = "nlptown/bert-base-multilingual-uncased-sentiment") -> None:
        self._model_name = model_name
        self._pipeline: Any = None

    def _load(self) -> Any:
        if self._pipeline is None:
            from transformers import pipeline as hf_pipeline
            self._pipeline = hf_pipeline(
                "sentiment-analysis",
                model=self._model_name,
                truncation=True,
                max_length=512,
            )
        return self._pipeline

    def predict(self, texts: list[str], batch_size: int = 16) -> list[SentimentOutput]:
        """Run sentiment prediction on a batch of texts.

        Args:
            texts: List of text strings.
            batch_size: Inference batch size.

        Returns:
            List of SentimentOutput.
        """
        pipe = self._load()
        results: list[SentimentOutput] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            preds = pipe(batch)
            for p in preds:
                results.append(SentimentOutput(label=p["label"], score=p["score"]))
        return results
