"""Shared test fixtures."""
from __future__ import annotations
import pytest
import numpy as np
from src.services.elo_service import EloService, MatchImportance
from src.services.xg_service import XGService
from src.services.injury_service import InjuryService, InjuryEntry
from src.services.odds_service import OddsService
from src.services.xgboost_service import XGBoostService
from src.services.monte_carlo_service import MonteCarloService, TeamConfig
from src.domain.value_objects.odds import OddsSnapshot
from datetime import date


@pytest.fixture
def elo_service() -> EloService:
    return EloService()


@pytest.fixture
def xg_service() -> XGService:
    return XGService()


@pytest.fixture
def injury_service() -> InjuryService:
    return InjuryService()


@pytest.fixture
def odds_service() -> OddsService:
    return OddsService()


@pytest.fixture
def xgb_service() -> XGBoostService:
    return XGBoostService()


@pytest.fixture
def mc_service(xgb_service: XGBoostService) -> MonteCarloService:
    return MonteCarloService(model_service=xgb_service)


@pytest.fixture
def sample_teams() -> list[TeamConfig]:
    return [
        TeamConfig(team_id=1, code="BRA", name="Brazil", group="A", elo=1950, xg_diff=0.8),
        TeamConfig(team_id=2, code="ARG", name="Argentina", group="A", elo=2100, xg_diff=1.2),
        TeamConfig(team_id=3, code="GER", name="Germany", group="A", elo=1850, xg_diff=0.5),
        TeamConfig(team_id=4, code="FRA", name="France", group="A", elo=2050, xg_diff=1.0),
        TeamConfig(team_id=5, code="ESP", name="Spain", group="B", elo=1920, xg_diff=0.9),
        TeamConfig(team_id=6, code="ENG", name="England", group="B", elo=1980, xg_diff=0.7),
        TeamConfig(team_id=7, code="NED", name="Netherlands", group="B", elo=1900, xg_diff=0.6),
        TeamConfig(team_id=8, code="POR", name="Portugal", group="B", elo=1930, xg_diff=0.8),
    ]


@pytest.fixture
def sample_odds_snapshots() -> list[OddsSnapshot]:
    return [
        OddsSnapshot(
            bookmaker="bet365",
            home_win=2.10, draw=3.40, away_win=3.50,
            timestamp="2026-06-01T12:00:00",
        ),
        OddsSnapshot(
            bookmaker="pinnacle",
            home_win=2.05, draw=3.45, away_win=3.60,
            timestamp="2026-06-01T12:00:00",
        ),
        OddsSnapshot(
            bookmaker="william_hill",
            home_win=2.15, draw=3.30, away_win=3.40,
            timestamp="2026-06-01T12:00:00",
        ),
    ]


@pytest.fixture
def sample_squad() -> list[dict]:
    return [
        {"name": "Player A", "position": "GK", "market_value": 50_000_000, "appearances": 10},
        {"name": "Player B", "position": "DEF", "market_value": 60_000_000, "appearances": 9},
        {"name": "Player C", "position": "MID", "market_value": 80_000_000, "appearances": 10},
        {"name": "Player D", "position": "FWD", "market_value": 100_000_000, "appearances": 8},
    ]


@pytest.fixture
def sample_injuries() -> list[InjuryEntry]:
    return [
        InjuryEntry(
            player_name="Player C",
            position="MID",
            market_value=80_000_000,
            injury_type="Hamstring",
            expected_return=date(2026, 7, 1),
            recent_appearances=10,
        ),
    ]
