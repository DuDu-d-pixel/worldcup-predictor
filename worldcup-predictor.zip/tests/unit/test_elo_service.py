"""Tests for Elo rating service."""
from __future__ import annotations
import pytest
from src.services.elo_service import EloService, MatchImportance


class TestEloService:
    def test_expected_score_equal_ratings(self, elo_service: EloService) -> None:
        """Equal ratings should give 0.5 expected score."""
        result = elo_service.calculate_expected_score(1500, 1500)
        assert result == pytest.approx(0.5, abs=0.001)

    def test_expected_score_higher_rated(self, elo_service: EloService) -> None:
        """Higher-rated team should have > 0.5 expected score."""
        result = elo_service.calculate_expected_score(1800, 1500)
        assert result > 0.8

    def test_expected_score_lower_rated(self, elo_service: EloService) -> None:
        """Lower-rated team should have < 0.5 expected score."""
        result = elo_service.calculate_expected_score(1500, 1800)
        assert result < 0.2

    def test_update_ratings_favorite_wins(self, elo_service: EloService) -> None:
        """When favorite wins, their rating should increase slightly."""
        result = elo_service.update_ratings(
            home_elo=1800, away_elo=1500,
            home_goals=2, away_goals=0,
            importance=MatchImportance.GROUP_STAGE,
        )
        assert result.new_home_elo > 1800
        assert result.new_away_elo < 1500

    def test_update_ratings_underdog_wins(self, elo_service: EloService) -> None:
        """When underdog wins, big rating swing."""
        result = elo_service.update_ratings(
            home_elo=1500, away_elo=1800,
            home_goals=3, away_goals=1,
            importance=MatchImportance.GROUP_STAGE,
        )
        assert result.new_home_elo > 1500  # Underdog gained
        assert result.new_away_elo < 1800  # Favorite lost

    def test_update_ratings_draw(self, elo_service: EloService) -> None:
        """Draw between equal teams should keep ratings stable."""
        result = elo_service.update_ratings(
            home_elo=1600, away_elo=1600,
            home_goals=1, away_goals=1,
            importance=MatchImportance.GROUP_STAGE,
        )
        # Home gets slight boost (home advantage), away gets slight penalty
        assert abs(result.new_home_elo - 1600) < 20
        assert abs(result.new_away_elo - 1600) < 20

    def test_k_factor_by_importance(self, elo_service: EloService) -> None:
        """Final should have higher K-factor than friendly."""
        k_final = elo_service.calculate_k_factor(MatchImportance.FINAL)
        k_friendly = elo_service.calculate_k_factor(MatchImportance.FRIENDLY)
        assert k_final > k_friendly

    def test_goal_difference_multiplier(self, elo_service: EloService) -> None:
        """Bigger goal difference should cause larger rating change."""
        close = elo_service.update_ratings(
            1600, 1600, 1, 0, MatchImportance.GROUP_STAGE
        )
        blowout = elo_service.update_ratings(
            1600, 1600, 5, 0, MatchImportance.GROUP_STAGE
        )
        diff_close = abs(close.new_home_elo - 1600)
        diff_blowout = abs(blowout.new_home_elo - 1600)
        assert diff_blowout > diff_close

    def test_win_probability_neutral(self, elo_service: EloService) -> None:
        """Win probability at neutral venue."""
        prob = elo_service.win_probability(1800, 1600, is_neutral=True)
        assert 0.5 < prob < 1.0

    def test_win_probability_with_home_advantage(self, elo_service: EloService) -> None:
        """Home advantage should increase win probability."""
        prob_neutral = elo_service.win_probability(1600, 1600, is_neutral=True)
        prob_home = elo_service.win_probability(1600, 1600, is_neutral=False)
        assert prob_home > prob_neutral
