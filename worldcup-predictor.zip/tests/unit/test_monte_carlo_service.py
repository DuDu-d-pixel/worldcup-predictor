"""Tests for Monte Carlo simulation service."""
from __future__ import annotations
import pytest
from src.services.monte_carlo_service import MonteCarloService, TeamConfig


class TestMonteCarloService:
    def test_probabilities_sum_to_one(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Total win probabilities should approximately sum to 1.0."""
        result = mc_service.simulate_tournament(sample_teams, num_simulations=1000, seed=42)
        total_prob = sum(r.win_probability for r in result.results)
        assert total_prob == pytest.approx(1.0, abs=0.05)

    def test_stronger_team_higher_probability(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Teams with higher Elo should have higher win probability."""
        result = mc_service.simulate_tournament(sample_teams, num_simulations=1000, seed=42)
        probs = {r.team_code: r.win_probability for r in result.results}
        # Argentina (2100 Elo) should have higher win probability than Germany (1850)
        assert probs.get("ARG", 0) > probs.get("GER", 0)

    def test_all_teams_have_results(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Every team should have a result entry."""
        result = mc_service.simulate_tournament(sample_teams, num_simulations=100, seed=42)
        assert len(result.results) == len(sample_teams)

    def test_sorted_by_win_prob(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Results should be sorted by win probability descending."""
        result = mc_service.simulate_tournament(sample_teams, num_simulations=1000, seed=42)
        sorted_results = result.sorted_by_win_prob
        for i in range(len(sorted_results) - 1):
            assert sorted_results[i].win_probability >= sorted_results[i + 1].win_probability

    def test_reproducible_with_seed(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Same seed should produce same results."""
        r1 = mc_service.simulate_tournament(sample_teams, num_simulations=500, seed=42)
        r2 = mc_service.simulate_tournament(sample_teams, num_simulations=500, seed=42)
        probs1 = [r.win_probability for r in r1.sorted_by_win_prob]
        probs2 = [r.win_probability for r in r2.sorted_by_win_prob]
        assert probs1 == probs2

    def test_different_seeds_different_results(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """Different seeds should produce different results."""
        r1 = mc_service.simulate_tournament(sample_teams, num_simulations=500, seed=42)
        r2 = mc_service.simulate_tournament(sample_teams, num_simulations=500, seed=99)
        probs1 = [r.win_probability for r in r1.sorted_by_win_prob]
        probs2 = [r.win_probability for r in r2.sorted_by_win_prob]
        assert probs1 != probs2

    def test_higher_simulations_smoother(
        self, mc_service: MonteCarloService, sample_teams
    ) -> None:
        """More simulations should give non-zero probabilities for strong teams."""
        result = mc_service.simulate_tournament(sample_teams, num_simulations=5000, seed=42)
        # At least one team should have > 10% win probability
        max_prob = max(r.win_probability for r in result.results)
        assert max_prob > 0.10
