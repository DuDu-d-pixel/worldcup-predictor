"""Tests for odds conversion service."""
from __future__ import annotations
import pytest
from src.services.odds_service import OddsService, AggregatedOdds
from src.domain.value_objects.odds import OddsSnapshot, OddsMovement


class TestOddsService:
    def test_implied_probability(self, odds_service: OddsService) -> None:
        """Decimal odds 2.0 should give 50% probability."""
        assert odds_service.implied_probability(2.0) == pytest.approx(0.5)

    def test_implied_probability_favorite(self, odds_service: OddsService) -> None:
        """Low odds = high probability."""
        assert odds_service.implied_probability(1.25) == pytest.approx(0.8)

    def test_implied_probability_invalid(self, odds_service: OddsService) -> None:
        """Odds <= 1.0 should raise error."""
        with pytest.raises(ValueError):
            odds_service.implied_probability(1.0)
        with pytest.raises(ValueError):
            odds_service.implied_probability(0.5)

    def test_remove_overround_sums_to_one(self, odds_service: OddsService) -> None:
        """Fair probabilities should sum to 1.0."""
        h, d, a = odds_service.remove_overround(2.10, 3.40, 3.50)
        assert h + d + a == pytest.approx(1.0, abs=0.001)

    def test_remove_overround_favors_home(self, odds_service: OddsService) -> None:
        """Lower home odds = higher home probability."""
        h, d, a = odds_service.remove_overround(1.50, 4.00, 6.00)
        assert h > a
        assert h > d

    def test_aggregate_odds_multiple_bookmakers(
        self, odds_service: OddsService, sample_odds_snapshots
    ) -> None:
        """Aggregation should produce valid probabilities."""
        result = odds_service.aggregate_odds(sample_odds_snapshots)
        total = result.home_win_prob + result.draw_prob + result.away_win_prob
        assert total == pytest.approx(1.0, abs=0.02)
        assert result.num_bookmakers == 3
        assert 0 <= result.confidence <= 1

    def test_aggregate_odds_empty(self, odds_service: OddsService) -> None:
        """Empty input should return zeros."""
        result = odds_service.aggregate_odds([])
        assert result.home_win_prob == 0.0

    def test_analyze_movement_no_change(self, odds_service: OddsService) -> None:
        """Same opening and current = no movement."""
        snap = OddsSnapshot("bet365", 2.0, 3.0, 4.0, "2026-01-01")
        movement = OddsMovement(opening=snap, current=snap)
        analysis = odds_service.analyze_movement(movement)
        assert analysis.home_prob_shift == pytest.approx(0.0, abs=0.001)
        assert analysis.direction == "balanced"

    def test_analyze_movement_steam_move(self, odds_service: OddsService) -> None:
        """Significant odds shift should detect steam move."""
        opening = OddsSnapshot("bet365", 2.50, 3.20, 3.00, "2026-01-01")
        current = OddsSnapshot("bet365", 1.80, 3.50, 4.50, "2026-01-02")
        movement = OddsMovement(opening=opening, current=current)
        analysis = odds_service.analyze_movement(movement)
        assert analysis.steam_move is True
        assert analysis.direction == "home"

    def test_odds_to_features(self, odds_service: OddsService) -> None:
        """Feature dict should contain expected keys."""
        agg = AggregatedOdds(0.45, 0.28, 0.27, 0.05, 3, 0.9)
        features = odds_service.odds_to_features(agg)
        assert "odds_home_prob" in features
        assert "odds_draw_prob" in features
        assert "odds_away_prob" in features
