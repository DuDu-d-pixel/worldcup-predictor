"""Tests for injury scoring service."""
from __future__ import annotations
import pytest
from datetime import date
from src.services.injury_service import InjuryService, InjuryEntry


class TestInjuryService:
    def test_healthy_team(self, injury_service: InjuryService, sample_squad) -> None:
        """No injuries = score of 0."""
        report = injury_service.compute_injury_report(sample_squad, [], date(2026, 6, 1))
        assert report.injury_score == 0.0
        assert report.injured_players == 0

    def test_injured_team(self, injury_service: InjuryService, sample_squad, sample_injuries) -> None:
        """Injured player should increase score."""
        report = injury_service.compute_injury_report(
            sample_squad, sample_injuries, date(2026, 6, 1)
        )
        assert report.injury_score > 0.0
        assert report.injured_players == 1

    def test_multiple_injuries(self, injury_service: InjuryService, sample_squad) -> None:
        """More injuries = higher score (or both at cap)."""
        single = [InjuryEntry("P1", "DEF", 30_000_000, "Sprain", date(2026, 7, 1), 6)]
        double = [
            InjuryEntry("P1", "DEF", 30_000_000, "Sprain", date(2026, 7, 1), 6),
            InjuryEntry("P2", "MID", 40_000_000, "ACL", date(2026, 12, 1), 8),
        ]
        report_single = injury_service.compute_injury_report(sample_squad, single, date(2026, 6, 1))
        report_double = injury_service.compute_injury_report(sample_squad, double, date(2026, 6, 1))
        assert report_double.injury_score >= report_single.injury_score
        assert report_double.injured_players > report_single.injured_players

    def test_returned_player_not_counted(self, injury_service: InjuryService, sample_squad) -> None:
        """Player past expected return date should not be counted."""
        past_injuries = [
            InjuryEntry("P1", "MID", 80_000_000, "Sprain", date(2026, 5, 1), 10)
        ]
        report = injury_service.compute_injury_report(
            sample_squad, past_injuries, date(2026, 6, 1)
        )
        assert report.injured_players == 0

    def test_availability_factor_healthy(self, injury_service: InjuryService) -> None:
        """Healthy team should have factor 1.0."""
        from src.domain.value_objects.injury_report import InjuryReport
        report = InjuryReport(total_players=23, injured_players=0, injury_score=0.0)
        assert injury_service.availability_factor(report) == 1.0

    def test_availability_factor_injured(self, injury_service: InjuryService) -> None:
        """Injured team should have factor < 1.0."""
        from src.domain.value_objects.injury_report import InjuryReport
        report = InjuryReport(total_players=23, injured_players=5, injury_score=0.5)
        factor = injury_service.availability_factor(report)
        assert factor < 1.0
        assert factor > 0.7

    def test_empty_squad(self, injury_service: InjuryService) -> None:
        """Empty squad should return default report."""
        report = injury_service.compute_injury_report([], [], date(2026, 6, 1))
        assert report.injury_score == 0.0
