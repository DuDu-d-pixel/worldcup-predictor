#!/bin/bash
# 🏆 世界杯预测平台 - 启动脚本

echo "🏆 世界杯冠军概率预测平台启动中..."

# 设置环境变量
export PYTHONPATH=$(pwd)
export DATABASE_URL="sqlite+aiosqlite:///./worldcup.db"

# 初始化数据库 (如果不存在)
if [ ! -f "worldcup.db" ]; then
    echo "📦 初始化数据库..."
    python scripts/seed_data.py

    echo "🎲 运行初始模拟..."
    python -c "
import asyncio
from src.services.scheduler import UpdateScheduler
async def run():
    s = UpdateScheduler(interval_minutes=15)
    await s._recalculate_probabilities()
    print('✅ 初始模拟完成')
asyncio.run(run())
"
fi

# 启动服务
echo "🚀 启动服务..."
exec uvicorn src.main:app --host 0.0.0.0 --port ${PORT:-8000}
