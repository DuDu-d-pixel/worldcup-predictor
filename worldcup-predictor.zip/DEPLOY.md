# 🏆 世界杯预测平台 - 部署指南

## 快速部署到云服务器

### 第一步：购买服务器

推荐配置：2核4G Ubuntu 22.04，约 ¥30-50/月

- [阿里云轻量服务器](https://www.aliyun.com/product/swas)
- [腾讯云轻量服务器](https://cloud.tencent.com/product/lighthouse)

### 第二步：上传代码

**方法1：使用 Git (推荐)**
```bash
# 1. 先把代码推送到 GitHub
# 2. 在服务器上克隆
cd /opt
git clone https://github.com/yourusername/worldcup-predictor.git worldcup
cd worldcup
```

**方法2：使用 SCP 上传**
```bash
# 在本地电脑执行
scp -r /Users/apple/Desktop/世界杯赔率计算/* root@你的服务器IP:/opt/worldcup/
```

### 第三步：运行部署脚本

```bash
# SSH 登录服务器
ssh root@你的服务器IP

# 运行部署脚本
cd /opt/worldcup
bash scripts/server_deploy.sh
```

### 第四步：访问网站

部署完成后，访问：
```
http://你的服务器IP:8000
```

## 常用命令

```bash
# 查看服务状态
sudo systemctl status worldcup

# 查看实时日志
sudo journalctl -u worldcup -f

# 重启服务
sudo systemctl restart worldcup

# 停止服务
sudo systemctl stop worldcup

# 更新代码后重启
cd /opt/worldcup
git pull
sudo systemctl restart worldcup
```

## 配置域名 (可选)

1. 购买域名 (如 worldcup.com)
2. 添加 A 记录指向服务器 IP
3. 配置 Nginx 反向代理

### Nginx 配置示例

```nginx
server {
    listen 80;
    server_name worldcup.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 数据更新

系统每15分钟自动更新一次：
- 赔率波动
- 球队情绪
- 伤病情况
- 重新计算概率

## 故障排查

**服务无法启动：**
```bash
# 查看错误日志
sudo journalctl -u worldcup -n 50

# 检查端口是否被占用
sudo lsof -i :8000

# 手动测试启动
cd /opt/worldcup
source venv/bin/activate
PYTHONPATH=/opt/worldcup uvicorn src.main:app --host 0.0.0.0 --port 8000
```

**数据库问题：**
```bash
# 重新初始化数据库
cd /opt/worldcup
source venv/bin/activate
PYTHONPATH=/opt/worldcup python scripts/seed_data.py
```
