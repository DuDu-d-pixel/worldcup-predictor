# 🏆 世界杯冠军概率预测平台

基于量化方法的世界杯冠军概率预测平台，融合 Elo 评级、xG 特征工程、伤病分析、博彩赔率、NLP 情绪分析和 Monte Carlo 模拟。

## 架构

```
┌─────────────────────────────────────────────┐
│  API Layer (FastAPI + Pydantic)             │
├─────────────────────────────────────────────┤
│  Application Layer (Use Cases + DTOs)       │
├─────────────────────────────────────────────┤
│  Domain Layer (Entities + Value Objects)    │
├─────────────────────────────────────────────┤
│  Infrastructure Layer (DB, Cache, APIs)     │
└─────────────────────────────────────────────┘
```

## 核心算法

| 模块 | 说明 |
|------|------|
| **Elo 评级系统** | 基于比赛结果的动态评级，含主场优势和比赛重要性 K 因子 |
| **xG 特征工程** | 从 FBref 采集预期进球数据，计算趋势和主客场差异 |
| **伤病评分系统** | 基于球员身价、位置和出场率的伤病影响评估 |
| **赔率隐含概率** | 多博彩公司加权聚合，去除 overround，检测 steam move |
| **NLP 情绪分析** | 多语言 BERT 模型分析新闻情绪，指数衰减加权 |
| **XGBoost 模型** | 26 维特征向量训练比赛结果预测模型 |
| **Monte Carlo 模拟** | 10 万次完整世界杯赛程模拟，输出每队夺冠概率 |

## 快速开始

### Docker 部署 (推荐)

```bash
# 1. 启动服务
cd docker && docker-compose up -d --build

# 2. 初始化数据
docker-compose run --rm worker python scripts/seed_data.py

# 3. 访问 API 文档
open http://localhost:8000/docs
```

### 本地开发

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp docker/.env.example .env

# 3. 初始化数据库
python scripts/seed_data.py

# 4. 启动服务
make run

# 5. 运行测试
make test
```

## API 端点

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/api/v1/health` | 健康检查 |
| `GET` | `/api/v1/teams` | 球队列表 |
| `GET` | `/api/v1/teams/{code}` | 球队详情 |
| `GET` | `/api/v1/predictions` | 所有球队夺冠概率 |
| `GET` | `/api/v1/predictions/{code}` | 单队预测详情 |
| `POST` | `/api/v1/predictions/match` | 比赛结果预测 |
| `POST` | `/api/v1/simulations/run` | 触发 Monte Carlo 模拟 |
| `GET` | `/api/v1/simulations` | 最新模拟结果 |
| `GET` | `/api/v1/odds/{match_id}` | 比赛赔率历史 |

## 项目结构

```
世界杯赔率计算/
├── src/
│   ├── main.py                    # FastAPI 入口
│   ├── config.py                  # 配置管理
│   ├── domain/                    # 领域层
│   │   ├── entities/              # 实体
│   │   ├── value_objects/         # 值对象
│   │   └── interfaces/            # 接口定义
│   ├── application/               # 应用层
│   ├── infrastructure/            # 基础设施层
│   │   ├── database/              # PostgreSQL + SQLAlchemy
│   │   ├── cache/                 # Redis 缓存
│   │   └── external_apis/         # 外部数据源
│   ├── services/                  # 核心算法服务
│   ├── api/                       # API 路由
│   └── schemas/                   # Pydantic 模型
├── tests/                         # 测试
├── scripts/                       # 工具脚本
├── docker/                        # Docker 配置
├── alembic/                       # 数据库迁移
└── Makefile
```

## 技术栈

- **Web**: FastAPI + Uvicorn
- **数据库**: PostgreSQL + SQLAlchemy 2.0 (async)
- **缓存**: Redis
- **ML**: XGBoost + scikit-learn
- **NLP**: Transformers (BERT)
- **数据采集**: httpx + BeautifulSoup4
- **容器化**: Docker + docker-compose

## 测试

```bash
make test          # 运行全部测试
make test-unit     # 仅单元测试
make test-cov      # 带覆盖率
```
