"""Fetch real data from external sources — odds, xG, injuries."""
from __future__ import annotations
import asyncio
import json
import logging
import random
from datetime import datetime, timedelta
from pathlib import Path

import httpx
from bs4 import BeautifulSoup
from tenacity import retry, stop_after_attempt, wait_exponential

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# Team name mapping (English → various sources)
# ─────────────────────────────────────────────────────────────
TEAM_MAP = {
    "Argentina": {"code": "ARG", "fbref": "Argentina", "odds": "Argentina"},
    "France": {"code": "FRA", "fbref": "France", "odds": "France"},
    "England": {"code": "ENG", "fbref": "England", "odds": "England"},
    "Brazil": {"code": "BRA", "fbref": "Brazil", "odds": "Brazil"},
    "Portugal": {"code": "POR", "fbref": "Portugal", "odds": "Portugal"},
    "Spain": {"code": "ESP", "fbref": "Spain", "odds": "Spain"},
    "Netherlands": {"code": "NED", "fbref": "Netherlands", "odds": "Netherlands"},
    "Germany": {"code": "GER", "fbref": "Germany", "odds": "Germany"},
    "Colombia": {"code": "COL", "fbref": "Colombia", "odds": "Colombia"},
    "Belgium": {"code": "BEL", "fbref": "Belgium", "odds": "Belgium"},
    "Croatia": {"code": "CRO", "fbref": "Croatia", "odds": "Croatia"},
    "Uruguay": {"code": "URU", "fbref": "Uruguay", "odds": "Uruguay"},
    "Morocco": {"code": "MAR", "fbref": "Morocco", "odds": "Morocco"},
    "USA": {"code": "USA", "fbref": "United States", "odds": "United States"},
    "Mexico": {"code": "MEX", "fbref": "Mexico", "odds": "Mexico"},
    "Senegal": {"code": "SEN", "fbref": "Senegal", "odds": "Senegal"},
    "Switzerland": {"code": "SUI", "fbref": "Switzerland", "odds": "Switzerland"},
    "Japan": {"code": "JPN", "fbref": "Japan", "odds": "Japan"},
    "Austria": {"code": "AUT", "fbref": "Austria", "odds": "Austria"},
    "South Korea": {"code": "KOR", "fbref": "South Korea", "odds": "South Korea"},
    "Turkey": {"code": "TUR", "fbref": "Turkey", "odds": "Turkey"},
    "Ecuador": {"code": "ECU", "fbref": "Ecuador", "odds": "Ecuador"},
    "Sweden": {"code": "SWE", "fbref": "Sweden", "odds": "Sweden"},
    "Egypt": {"code": "EGY", "fbref": "Egypt", "odds": "Egypt"},
    "Norway": {"code": "NOR", "fbref": "Norway", "odds": "Norway"},
    "Australia": {"code": "AUS", "fbref": "Australia", "odds": "Australia"},
    "Iran": {"code": "IRN", "fbref": "Iran", "odds": "Iran"},
    "Tunisia": {"code": "TUN", "fbref": "Tunisia", "odds": "Tunisia"},
    "Paraguay": {"code": "PAR", "fbref": "Paraguay", "odds": "Paraguay"},
    "Ivory Coast": {"code": "CIV", "fbref": "Côte d'Ivoire", "odds": "Ivory Coast"},
    "Scotland": {"code": "SCO", "fbref": "Scotland", "odds": "Scotland"},
    "Ghana": {"code": "GHA", "fbref": "Ghana", "odds": "Ghana"},
    "Canada": {"code": "CAN", "fbref": "Canada", "odds": "Canada"},
    "Algeria": {"code": "ALG", "fbref": "Algeria", "odds": "Algeria"},
    "Czech Republic": {"code": "CZE", "fbref": "Czech Republic", "odds": "Czech Republic"},
    "Qatar": {"code": "QAT", "fbref": "Qatar", "odds": "Qatar"},
    "Saudi Arabia": {"code": "KSA", "fbref": "Saudi Arabia", "odds": "Saudi Arabia"},
    "Panama": {"code": "PAN", "fbref": "Panama", "odds": "Panama"},
    "Iraq": {"code": "IRQ", "fbref": "Iraq", "odds": "Iraq"},
    "Bosnia Herzegovina": {"code": "BIH", "fbref": "Bosnia and Herzegovina", "odds": "Bosnia and Herzegovina"},
    "DR Congo": {"code": "COD", "fbref": "DR Congo", "odds": "Congo DR"},
    "Jordan": {"code": "JOR", "fbref": "Jordan", "odds": "Jordan"},
    "New Zealand": {"code": "NZL", "fbref": "New Zealand", "odds": "New Zealand"},
    "Uzbekistan": {"code": "UZB", "fbref": "Uzbekistan", "odds": "Uzbekistan"},
    "Haiti": {"code": "HAI", "fbref": "Haiti", "odds": "Haiti"},
    "Cape Verde": {"code": "CPV", "fbref": "Cape Verde", "odds": "Cape Verde Islands"},
    "Curaçao": {"code": "CUW", "fbref": "Curaçao", "odds": "Curacao"},
    "South Africa": {"code": "RSA", "fbref": "South Africa", "odds": "South Africa"},
}


# ─────────────────────────────────────────────────────────────
# 1. Fetch real odds from the-odds-api.com (FREE: 500 req/month)
# ─────────────────────────────────────────────────────────────
async def fetch_real_odds(api_key: str) -> dict[str, list[dict]]:
    """Fetch real World Cup winner odds from the-odds-api.com.

    Get free API key at: https://the-odds-api.com/
    """
    if not api_key:
        logger.warning("No odds API key provided, skipping real odds fetch")
        return {}

    url = "https://api.the-odds-api.com/v4/sports/soccer_fifa_world_cup_winner/odds"
    params = {
        "apiKey": api_key,
        "regions": "eu,uk,us",
        "markets": "outrights",
        "oddsFormat": "decimal",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
            data = resp.json()

            odds_by_team: dict[str, list[dict]] = []
            for event in data:
                for bookmaker in event.get("bookmakers", []):
                    for market in bookmaker.get("markets", []):
                        for outcome in market.get("outcomes", []):
                            team = outcome["name"]
                            price = outcome["price"]
                            odds_by_team.setdefault(team, []).append({
                                "bookmaker": bookmaker["key"],
                                "odds": price,
                                "implied_prob": round(1.0 / price, 4),
                            })

            logger.info(f"Fetched real odds for {len(odds_by_team)} teams")
            return odds_by_team

        except Exception as e:
            logger.error(f"Failed to fetch odds: {e}")
            return {}


# ─────────────────────────────────────────────────────────────
# 2. Fetch xG data from FBref (FREE)
# ─────────────────────────────────────────────────────────────
@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=10))
async def fetch_fbref_xg(team_name: str) -> tuple[float, float] | None:
    """Fetch real xG/xGA data from FBref for a national team.

    Returns (xG_per_90, xGA_per_90) or None if failed.
    """
    url = f"https://fbref.com/en/search/search.fcgi?search={team_name}"

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
    }

    async with httpx.AsyncClient(timeout=30, follow_redirects=True, headers=headers) as client:
        try:
            resp = await client.get(url)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "lxml")

            # Look for the team stats table
            tables = soup.find_all("table")
            for table in tables:
                if "stats" in table.get("id", "").lower():
                    rows = table.find_all("tr")
                    for row in rows:
                        cells = row.find_all("td")
                        # Try to extract xG values
                        for i, cell in enumerate(cells):
                            text = cell.text.strip()
                            if "xG" in cell.get("data-stat", ""):
                                try:
                                    xg = float(text)
                                    # Look for xGA in same row
                                    for j, c2 in enumerate(cells):
                                        if "xGA" in c2.get("data-stat", ""):
                                            xga = float(c2.text.strip())
                                            return (round(xg, 2), round(xga, 2))
                                except ValueError:
                                    continue

            logger.warning(f"Could not parse xG for {team_name}")
            return None

        except Exception as e:
            logger.warning(f"FBref fetch failed for {team_name}: {e}")
            return None


# ─────────────────────────────────────────────────────────────
# 3. Fetch injury data from Transfermarkt (FREE)
# ─────────────────────────────────────────────────────────────
@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=10))
async def fetch_transfermarkt_injuries(team_slug: str) -> list[dict]:
    """Fetch real injury data from Transfermarkt.

    Args:
        team_slug: URL slug like "argentinien/startseite/verein/3435"
    """
    url = f"https://www.transfermarkt.com/{team_slug}/verletzungen/verein"
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
    }

    async with httpx.AsyncClient(timeout=30, follow_redirects=True, headers=headers) as client:
        try:
            resp = await client.get(url)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "lxml")

            injuries = []
            table = soup.find("table", {"class": "items"})
            if table:
                rows = table.find_all("tr", {"class": ["odd", "even"]})
                for row in rows:
                    cells = row.find_all("td")
                    if len(cells) >= 5:
                        name = cells[1].text.strip()
                        position = cells[2].text.strip()
                        injury = cells[3].text.strip()
                        market_val = cells[4].text.strip() if len(cells) > 4 else ""

                        injuries.append({
                            "name": name,
                            "position": position,
                            "injury": injury,
                            "market_value": market_val,
                        })

            logger.info(f"Found {len(injuries)} injuries for {team_slug}")
            return injuries

        except Exception as e:
            logger.warning(f"Transfermarkt fetch failed: {e}")
            return []


# ─────────────────────────────────────────────────────────────
# 4. Fetch real Elo ratings from clubelo.com (FREE)
# ─────────────────────────────────────────────────────────────
@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=5))
async def fetch_real_elo(country: str) -> float | None:
    """Fetch real Elo rating from clubelo.com."""
    url = f"http://api.clubelo.com/{country}"
    async with httpx.AsyncClient(timeout=15) as client:
        try:
            resp = await client.get(url)
            if resp.status_code == 200:
                # Response is CSV-like: Country,Elo,...
                lines = resp.text.strip().split("\n")
                if len(lines) >= 2:
                    parts = lines[1].split(",")
                    if len(parts) >= 2:
                        elo = float(parts[1])
                        logger.info(f"{country}: Elo = {elo}")
                        return round(elo, 1)
            return None
        except Exception as e:
            logger.warning(f"Elo fetch failed for {country}: {e}")
            return None


# ─────────────────────────────────────────────────────────────
# Main: Update database with real data
# ─────────────────────────────────────────────────────────────
async def update_database(odds_api_key: str = "") -> None:
    """Update database with real data from all sources."""
    from src.infrastructure.database.session import async_session_factory
    from src.infrastructure.database.models import TeamModel, OddsModel
    from sqlalchemy import select, delete

    async with async_session_factory() as session:
        result = await session.execute(select(TeamModel))
        teams = result.scalars().all()

        updated_count = 0

        for team in teams:
            team_info = TEAM_MAP.get(team.name)
            if not team_info:
                continue

            # Fetch real Elo
            elo = await fetch_real_elo(team_info["code"])
            if elo:
                team.elo = elo
                updated_count += 1

            # Small delay to be polite to APIs
            await asyncio.sleep(0.5)

        await session.commit()
        logger.info(f"Updated Elo for {updated_count} teams")

        # Fetch real odds
        if odds_api_key:
            real_odds = await fetch_real_odds(odds_api_key)
            if real_odds:
                # Clear old odds
                await session.execute(delete(OddsModel))

                for team_name, odds_list in real_odds.items():
                    for o in odds_list:
                        session.add(OddsModel(
                            bookmaker=o["bookmaker"],
                            team=team_name,
                            odds=o["odds"],
                            implied_prob=o["implied_prob"],
                        ))

                await session.commit()
                logger.info(f"Updated real odds for {len(real_odds)} teams")

    logger.info("✅ Real data update complete!")


if __name__ == "__main__":
    import sys
    api_key = sys.argv[1] if len(sys.argv) > 1 else ""
    asyncio.run(update_database(api_key))
