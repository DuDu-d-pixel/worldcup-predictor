#!/bin/bash
# World Cup Predictor - Quick Deploy Script

set -e

echo "🏆 世界杯冠军概率预测平台 - 部署脚本"
echo "=================================="
echo ""
echo "选择部署方式:"
echo "  1) 本机运行 (localhost)"
echo "  2) 局域网分享 (同WiFi)"
echo "  3) ngrok 公网分享 (临时)"
echo "  4) Docker 部署"
echo "  5) 退出"
echo ""
read -p "请选择 [1-5]: " choice

case $choice in
    1)
        echo "🚀 启动本机服务..."
        source .venv/bin/activate 2>/dev/null || true
        PYTHONPATH=$(pwd) uvicorn src.main:app --host 127.0.0.1 --port 8000 --reload
        ;;
    2)
        IP=$(ipconfig getifaddr en0 2>/dev/null || hostname -I | awk '{print $1}')
        echo "🚀 启动局域网服务..."
        echo ""
        echo "📱 分享给朋友: http://${IP}:8000"
        echo ""
        source .venv/bin/activate 2>/dev/null || true
        PYTHONPATH=$(pwd) uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
        ;;
    3)
        echo "🚀 启动 ngrok 公网隧道..."
        echo ""
        echo "步骤:"
        echo "  1. 先在另一个终端运行: make run"
        echo "  2. 然后运行: ngrok http 8000"
        echo "  3. 复制 https://xxx.ngrok-free.app 发给别人"
        echo ""
        read -p "服务已启动? 按回车启动 ngrok..."
        ngrok http 8000
        ;;
    4)
        echo "🚀 Docker 部署..."
        cd docker
        docker-compose up -d --build
        echo ""
        echo "✅ 部署完成!"
        echo "📱 访问: http://localhost:8000"
        echo "📖 文档: http://localhost:8000/docs"
        ;;
    5)
        exit 0
        ;;
    *)
        echo "无效选择"
        exit 1
        ;;
esac
