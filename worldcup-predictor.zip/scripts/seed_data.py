"""Seed database with REAL 2026 World Cup data — 12 groups, 48 teams, full schedule."""
from __future__ import annotations
import asyncio
import random
from datetime import datetime
from src.infrastructure.database.session import async_session_factory, init_db
from src.infrastructure.database.models import TeamModel, PlayerModel, OddsModel, MatchModel

# 12 Groups × 4 teams = 48 teams (REAL 2026 World Cup)
GROUPS = {
    "A": ["Mexico", "South Africa", "South Korea", "Czech Republic"],
    "B": ["Canada", "Switzerland", "Qatar", "Bosnia Herzegovina"],
    "C": ["Brazil", "Morocco", "Haiti", "Scotland"],
    "D": ["USA", "Paraguay", "Australia", "Turkey"],
    "E": ["Germany", "Curaçao", "Ivory Coast", "Ecuador"],
    "F": ["Netherlands", "Japan", "Tunisia", "Sweden"],
    "G": ["Belgium", "Egypt", "Iran", "New Zealand"],
    "H": ["Spain", "Cape Verde", "Saudi Arabia", "Uruguay"],
    "I": ["France", "Senegal", "Iraq", "Norway"],
    "J": ["Argentina", "Algeria", "Austria", "Jordan"],
    "K": ["Portugal", "Colombia", "Uzbekistan", "DR Congo"],
    "L": ["England", "Croatia", "Ghana", "Panama"],
}

# FIFA codes mapping
CODES = {
    "Mexico": "MEX", "South Africa": "RSA", "South Korea": "KOR", "Czech Republic": "CZE",
    "Canada": "CAN", "Switzerland": "SUI", "Qatar": "QAT", "Bosnia Herzegovina": "BIH",
    "Brazil": "BRA", "Morocco": "MAR", "Haiti": "HAI", "Scotland": "SCO",
    "USA": "USA", "Paraguay": "PAR", "Australia": "AUS", "Turkey": "TUR",
    "Germany": "GER", "Curaçao": "CUW", "Ivory Coast": "CIV", "Ecuador": "ECU",
    "Netherlands": "NED", "Japan": "JPN", "Tunisia": "TUN", "Sweden": "SWE",
    "Belgium": "BEL", "Egypt": "EGY", "Iran": "IRN", "New Zealand": "NZL",
    "Spain": "ESP", "Cape Verde": "CPV", "Saudi Arabia": "KSA", "Uruguay": "URU",
    "France": "FRA", "Senegal": "SEN", "Iraq": "IRQ", "Norway": "NOR",
    "Argentina": "ARG", "Algeria": "ALG", "Austria": "AUT", "Jordan": "JOR",
    "Portugal": "POR", "Colombia": "COL", "Uzbekistan": "UZB", "DR Congo": "COD",
    "England": "ENG", "Croatia": "CRO", "Ghana": "GHA", "Panama": "PAN",
}

# Chinese names
NAMES_CN = {
    "Mexico": "墨西哥", "South Africa": "南非", "South Korea": "韩国", "Czech Republic": "捷克",
    "Canada": "加拿大", "Switzerland": "瑞士", "Qatar": "卡塔尔", "Bosnia Herzegovina": "波黑",
    "Brazil": "巴西", "Morocco": "摩洛哥", "Haiti": "海地", "Scotland": "苏格兰",
    "USA": "美国", "Paraguay": "巴拉圭", "Australia": "澳大利亚", "Turkey": "土耳其",
    "Germany": "德国", "Curaçao": "库拉索", "Ivory Coast": "科特迪瓦", "Ecuador": "厄瓜多尔",
    "Netherlands": "荷兰", "Japan": "日本", "Tunisia": "突尼斯", "Sweden": "瑞典",
    "Belgium": "比利时", "Egypt": "埃及", "Iran": "伊朗", "New Zealand": "新西兰",
    "Spain": "西班牙", "Cape Verde": "佛得角", "Saudi Arabia": "沙特", "Uruguay": "乌拉圭",
    "France": "法国", "Senegal": "塞内加尔", "Iraq": "伊拉克", "Norway": "挪威",
    "Argentina": "阿根廷", "Algeria": "阿尔及利亚", "Austria": "奥地利", "Jordan": "约旦",
    "Portugal": "葡萄牙", "Colombia": "哥伦比亚", "Uzbekistan": "乌兹别克", "DR Congo": "刚果金",
    "England": "英格兰", "Croatia": "克罗地亚", "Ghana": "加纳", "Panama": "巴拿马",
}

# Elo ratings (realistic estimates based on FIFA rankings and historical performance)
ELO_RATINGS = {
    "Argentina": 2100, "France": 2050, "England": 1980, "Brazil": 1950,
    "Portugal": 1930, "Spain": 1920, "Netherlands": 1900, "Germany": 1850,
    "Uruguay": 1840, "Colombia": 1880, "Belgium": 1860, "Croatia": 1830,
    "Morocco": 1790, "USA": 1820, "Mexico": 1780, "Senegal": 1770,
    "Switzerland": 1760, "Japan": 1740, "Denmark": 1750, "Austria": 1730,
    "Sweden": 1710, "South Korea": 1700, "Turkey": 1700, "Ecuador": 1680,
    "Egypt": 1670, "Norway": 1660, "Paraguay": 1660, "Ivory Coast": 1650,
    "Scotland": 1630, "Australia": 1630, "Tunisia": 1620, "Iran": 1620,
    "Czech Republic": 1610, "Qatar": 1600, "Ghana": 1600, "Algeria": 1590,
    "Panama": 1580, "Saudi Arabia": 1570, "Iraq": 1550, "Bosnia Herzegovina": 1540,
    "Canada": 1620, "DR Congo": 1530, "New Zealand": 1400, "Jordan": 1500,
    "Haiti": 1450, "Uzbekistan": 1520, "South Africa": 1480, "Cape Verde": 1460,
    "Curaçao": 1420,
}

# xG stats (estimated from recent form)
XG_STATS = {
    "Argentina": (2.1, 0.6), "France": (2.0, 0.7), "England": (1.8, 0.8),
    "Brazil": (1.9, 0.9), "Portugal": (1.7, 0.8), "Spain": (2.2, 0.5),
    "Netherlands": (1.6, 0.7), "Germany": (1.8, 1.0), "Uruguay": (1.3, 0.8),
    "Colombia": (1.5, 0.8), "Belgium": (1.4, 0.9), "Croatia": (1.4, 0.9),
    "Morocco": (1.2, 0.7), "USA": (1.4, 1.0), "Mexico": (1.3, 1.1),
    "Senegal": (1.2, 0.9), "Switzerland": (1.1, 0.8), "Japan": (1.4, 1.0),
    "Austria": (1.2, 1.0), "Sweden": (1.1, 0.9), "South Korea": (1.2, 1.1),
    "Turkey": (1.3, 1.2), "Ecuador": (1.0, 1.0), "Egypt": (0.9, 1.0),
    "Norway": (1.1, 0.9), "Paraguay": (0.8, 1.1), "Ivory Coast": (1.1, 1.0),
    "Scotland": (0.9, 1.1), "Australia": (0.9, 1.3), "Tunisia": (0.8, 1.0),
    "Iran": (0.9, 1.0), "Czech Republic": (1.0, 1.1), "Qatar": (0.9, 1.2),
    "Ghana": (0.8, 1.3), "Algeria": (0.9, 1.1), "Panama": (0.7, 1.2),
    "Saudi Arabia": (0.7, 1.5), "Iraq": (0.7, 1.3), "Bosnia Herzegovina": (0.8, 1.2),
    "Canada": (1.0, 1.3), "DR Congo": (0.7, 1.4), "New Zealand": (0.5, 1.8),
    "Jordan": (0.7, 1.3), "Haiti": (0.6, 1.5), "Uzbekistan": (0.8, 1.2),
    "South Africa": (0.7, 1.3), "Cape Verde": (0.6, 1.4), "Curaçao": (0.5, 1.5),
}

# Squad market values (EUR, approximate)
SQUAD_VALUES = {
    "Argentina": 1_400_000_000, "France": 1_800_000_000, "England": 1_600_000_000,
    "Brazil": 1_500_000_000, "Portugal": 1_000_000_000, "Spain": 1_300_000_000,
    "Netherlands": 900_000_000, "Germany": 1_100_000_000, "Uruguay": 500_000_000,
    "Colombia": 500_000_000, "Belgium": 800_000_000, "Croatia": 450_000_000,
    "Morocco": 350_000_000, "USA": 1_200_000_000, "Mexico": 400_000_000,
    "Senegal": 300_000_000, "Switzerland": 300_000_000, "Japan": 300_000_000,
    "Austria": 300_000_000, "Sweden": 250_000_000, "South Korea": 250_000_000,
    "Turkey": 300_000_000, "Ecuador": 200_000_000, "Egypt": 120_000_000,
    "Norway": 200_000_000, "Paraguay": 130_000_000, "Ivory Coast": 200_000_000,
    "Scotland": 150_000_000, "Australia": 150_000_000, "Tunisia": 100_000_000,
    "Iran": 100_000_000, "Czech Republic": 200_000_000, "Qatar": 80_000_000,
    "Ghana": 150_000_000, "Algeria": 120_000_000, "Panama": 60_000_000,
    "Saudi Arabia": 80_000_000, "Iraq": 50_000_000, "Bosnia Herzegovina": 100_000_000,
    "Canada": 200_000_000, "DR Congo": 80_000_000, "New Zealand": 30_000_000,
    "Jordan": 40_000_000, "Haiti": 20_000_000, "Uzbekistan": 60_000_000,
    "South Africa": 50_000_000, "Cape Verde": 30_000_000, "Curaçao": 15_000_000,
}

# Full match schedule: (datetime, group, home_team, away_team)
MATCHES = [
    # Group A
    ("2026-06-16 09:00", "A", "Mexico", "South Africa"),
    ("2026-06-16 12:00", "A", "South Korea", "Czech Republic"),
    ("2026-06-21 09:00", "A", "Mexico", "South Korea"),
    ("2026-06-21 12:00", "A", "South Africa", "Czech Republic"),
    ("2026-06-25 09:00", "A", "Czech Republic", "Mexico"),
    ("2026-06-25 09:00", "A", "South Africa", "South Korea"),
    # Group B
    ("2026-06-16 22:00", "B", "Canada", "Switzerland"),
    ("2026-06-17 01:00", "B", "Qatar", "Bosnia Herzegovina"),
    ("2026-06-22 00:00", "B", "Canada", "Qatar"),
    ("2026-06-22 03:00", "B", "Switzerland", "Bosnia Herzegovina"),
    ("2026-06-26 04:00", "B", "Bosnia Herzegovina", "Canada"),
    ("2026-06-26 04:00", "B", "Switzerland", "Qatar"),
    # Group C
    ("2026-06-17 04:00", "C", "Brazil", "Morocco"),
    ("2026-06-17 07:00", "C", "Haiti", "Scotland"),
    ("2026-06-22 06:00", "C", "Brazil", "Haiti"),
    ("2026-06-22 09:00", "C", "Morocco", "Scotland"),
    ("2026-06-25 06:00", "C", "Morocco", "Haiti"),
    ("2026-06-25 06:00", "C", "Scotland", "Brazil"),
    # Group D
    ("2026-06-17 22:00", "D", "USA", "Paraguay"),
    ("2026-06-18 01:00", "D", "Australia", "Turkey"),
    ("2026-06-23 00:00", "D", "USA", "Australia"),
    ("2026-06-23 03:00", "D", "Paraguay", "Turkey"),
    ("2026-06-27 04:00", "D", "Turkey", "USA"),
    ("2026-06-27 04:00", "D", "Paraguay", "Australia"),
    # Group E
    ("2026-06-18 04:00", "E", "Germany", "Curaçao"),
    ("2026-06-18 07:00", "E", "Ivory Coast", "Ecuador"),
    ("2026-06-21 04:00", "E", "Germany", "Ivory Coast"),
    ("2026-06-21 08:00", "E", "Ecuador", "Curaçao"),
    ("2026-06-26 04:00", "E", "Ecuador", "Germany"),
    ("2026-06-26 04:00", "E", "Curaçao", "Ivory Coast"),
    # Group F
    ("2026-06-18 22:00", "F", "Netherlands", "Japan"),
    ("2026-06-19 01:00", "F", "Tunisia", "Sweden"),
    ("2026-06-21 01:00", "F", "Netherlands", "Sweden"),
    ("2026-06-21 04:00", "F", "Japan", "Tunisia"),
    ("2026-06-27 01:00", "F", "Sweden", "Japan"),
    ("2026-06-27 01:00", "F", "Tunisia", "Netherlands"),
    # Group G
    ("2026-06-16 03:00", "G", "Belgium", "Egypt"),
    ("2026-06-16 09:00", "G", "Iran", "New Zealand"),
    ("2026-06-22 03:00", "G", "Belgium", "Iran"),
    ("2026-06-22 09:00", "G", "New Zealand", "Egypt"),
    ("2026-06-26 01:00", "G", "New Zealand", "Belgium"),
    ("2026-06-26 01:00", "G", "Egypt", "Iran"),
    # Group H
    ("2026-06-16 06:00", "H", "Spain", "Cape Verde"),
    ("2026-06-16 06:00", "H", "Saudi Arabia", "Uruguay"),
    ("2026-06-22 00:00", "H", "Spain", "Saudi Arabia"),
    ("2026-06-22 06:00", "H", "Uruguay", "Cape Verde"),
    ("2026-06-27 07:00", "H", "Uruguay", "Spain"),
    ("2026-06-27 07:00", "H", "Cape Verde", "Saudi Arabia"),
    # Group I
    ("2026-06-17 03:00", "I", "France", "Senegal"),
    ("2026-06-17 01:00", "I", "Iraq", "Norway"),
    ("2026-06-23 06:00", "I", "France", "Iraq"),
    ("2026-06-23 09:00", "I", "Senegal", "Norway"),
    ("2026-06-28 01:00", "I", "Norway", "France"),
    ("2026-06-28 01:00", "I", "Iraq", "Senegal"),
    # Group J
    ("2026-06-17 04:00", "J", "Argentina", "Algeria"),
    ("2026-06-18 01:00", "J", "Austria", "Jordan"),
    ("2026-06-23 00:00", "J", "Argentina", "Austria"),
    ("2026-06-23 03:00", "J", "Algeria", "Jordan"),
    ("2026-06-28 04:00", "J", "Jordan", "Argentina"),
    ("2026-06-28 04:00", "J", "Austria", "Algeria"),
    # Group K
    ("2026-06-18 04:00", "K", "Portugal", "Colombia"),
    ("2026-06-18 07:00", "K", "Uzbekistan", "DR Congo"),
    ("2026-06-24 00:00", "K", "Portugal", "Uzbekistan"),
    ("2026-06-24 03:00", "K", "Colombia", "DR Congo"),
    ("2026-06-28 07:30", "K", "Colombia", "Portugal"),
    ("2026-06-28 07:30", "K", "DR Congo", "Uzbekistan"),
    # Group L
    ("2026-06-18 07:00", "L", "Ghana", "Panama"),
    ("2026-06-18 10:00", "L", "England", "Croatia"),
    ("2026-06-24 07:00", "L", "Panama", "Croatia"),
    ("2026-06-24 10:00", "L", "England", "Ghana"),
    ("2026-06-28 10:00", "L", "Panama", "England"),
    ("2026-06-28 10:00", "L", "Croatia", "Ghana"),
]

POSITIONS = ["GK", "DEF", "DEF", "DEF", "MID", "MID", "MID", "FWD", "FWD", "FWD",
             "GK", "DEF", "DEF", "MID", "MID", "FWD", "GK", "DEF", "MID", "FWD",
             "DEF", "MID", "FWD"]

BOOKMAKERS = ["bet365", "pinnacle", "william_hill", "unibet", "betfair"]


def _generate_players(team_name: str, team_id: int, squad_value: float) -> list[dict]:
    """Generate 23 players for a team."""
    avg_value = squad_value / 23
    players = []
    for i, pos in enumerate(POSITIONS):
        value_mult = {"GK": 0.6, "DEF": 0.8, "MID": 1.0, "FWD": 1.3}[pos]
        players.append({
            "team_id": team_id,
            "name": f"{team_name} Player {i+1}",
            "position": pos,
            "market_value": avg_value * value_mult * random.uniform(0.5, 2.0),
            "form_score": random.uniform(0.3, 1.0),
            "injury": random.random() < 0.08,
        })
    return players


def _generate_odds(team_name: str, elo: float) -> list[dict]:
    """Generate odds from multiple bookmakers for a team to win the World Cup."""
    base_prob = max(0.001, min(0.30, (elo - 1400) / 8000))
    odds_list = []
    for bm in BOOKMAKERS:
        variation = random.uniform(0.9, 1.15)
        decimal_odds = round(1.0 / (base_prob * variation), 2)
        decimal_odds = max(1.01, decimal_odds)
        odds_list.append({
            "bookmaker": bm,
            "team": team_name,
            "odds": decimal_odds,
            "implied_prob": round(1.0 / decimal_odds, 4),
        })
    return odds_list


async def seed() -> None:
    """Seed database with all World Cup data."""
    await init_db()
    async with async_session_factory() as session:
        from sqlalchemy import select, func
        count = await session.execute(select(func.count()).select_from(TeamModel))
        if count.scalar() > 0:
            print(f"Database already seeded.")
            return

        random.seed(42)

        # Insert teams
        team_name_to_id = {}
        for group_name, teams in GROUPS.items():
            for team_name in teams:
                code = CODES.get(team_name, team_name[:3].upper())
                elo = ELO_RATINGS.get(team_name, 1500)
                xg, xga = XG_STATS.get(team_name, (1.0, 1.0))
                value = SQUAD_VALUES.get(team_name, 100_000_000)

                team = TeamModel(
                    name=team_name, name_cn=NAMES_CN.get(team_name, team_name),
                    code=code, group_name=group_name,
                    elo=elo, xg=xg, xga=xga,
                    sentiment=round(random.uniform(-0.3, 0.5), 2),
                    injury_score=round(random.uniform(0.0, 0.3), 2),
                    squad_value=value,
                )
                session.add(team)
                await session.flush()
                team_name_to_id[team_name] = team.id

        # Insert players
        all_players = []
        for group_name, teams in GROUPS.items():
            for team_name in teams:
                team_id = team_name_to_id[team_name]
                value = SQUAD_VALUES.get(team_name, 100_000_000)
                all_players.extend(_generate_players(team_name, team_id, value))

        for p in all_players:
            session.add(PlayerModel(**p))

        # Insert odds
        all_odds = []
        for group_name, teams in GROUPS.items():
            for team_name in teams:
                elo = ELO_RATINGS.get(team_name, 1500)
                all_odds.extend(_generate_odds(team_name, elo))

        for o in all_odds:
            session.add(OddsModel(**o))

        # Insert match schedule
        for dt_str, group, home, away in MATCHES:
            match = MatchModel(
                home_team=home, away_team=away,
                home_team_cn=NAMES_CN.get(home, home),
                away_team_cn=NAMES_CN.get(away, away),
                match_date=datetime.strptime(dt_str, "%Y-%m-%d %H:%M"),
                group_name=group, match_type="group",
                tournament="FIFA World Cup 2026",
            )
            session.add(match)

        await session.commit()
        print(f"Seeded {sum(len(v) for v in GROUPS.values())} teams, "
              f"{len(all_players)} players, {len(all_odds)} odds, {len(MATCHES)} matches.")


if __name__ == "__main__":
    asyncio.run(seed())
