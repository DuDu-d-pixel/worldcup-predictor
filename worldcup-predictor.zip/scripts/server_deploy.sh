#!/bin/bash
# 🏆 世界杯预测平台 - 云服务器一键部署脚本
# 使用方法: 在服务器上运行 bash server_deploy.sh

set -e

echo "🏆 世界杯冠军概率预测平台 - 服务器部署"
echo "========================================"
echo ""

# 1. 更新系统
echo "📦 更新系统..."
sudo apt update && sudo apt upgrade -y

# 2. 安装依赖
echo "📦 安装 Python 和依赖..."
sudo apt install -y python3 python3-pip python3-venv git

# 3. 克隆代码 (或上传代码)
echo "📥 下载代码..."
cd /opt
sudo mkdir -p worldcup
sudo chown $USER:$USER worldcup
cd worldcup

# 如果有 Git 仓库:
# git clone https://github.com/yourusername/worldcup-predictor.git .
# 或者手动上传代码到 /opt/worldcup/

# 4. 创建虚拟环境
echo "🐍 创建 Python 环境..."
python3 -m venv venv
source venv/bin/activate

# 5. 安装依赖
echo "📦 安装 Python 包..."
pip install --upgrade pip
pip install fastapi uvicorn sqlalchemy aiosqlite pydantic pydantic-settings httpx xgboost scikit-learn numpy pandas beautifulsoup4 lxml python-dotenv tenacity

# 6. 初始化数据库
echo "🗄️ 初始化数据库..."
export PYTHONPATH=/opt/worldcup
python scripts/seed_data.py

# 7. 运行初始模拟
echo "🎲 运行初始 Monte Carlo 模拟..."
python -c "
import asyncio
from src.services.scheduler import UpdateScheduler
async def run():
    s = UpdateScheduler(interval_minutes=15)
    await s._recalculate_probabilities()
    print('✅ 初始模拟完成')
asyncio.run(run())
"

# 8. 创建 systemd 服务
echo "🔧 创建系统服务..."
sudo tee /etc/systemd/system/worldcup.service > /dev/null <<EOF
[Unit]
Description=World Cup Predictor API
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/worldcup
Environment=PYTHONPATH=/opt/worldcup
ExecStart=/opt/worldcup/venv/bin/uvicorn src.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# 9. 启动服务
echo "🚀 启动服务..."
sudo systemctl daemon-reload
sudo systemctl enable worldcup
sudo systemctl start worldcup

# 10. 配置防火墙
echo "🔥 配置防火墙..."
sudo ufw allow 8000/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

echo ""
echo "✅ 部署完成!"
echo ""
echo "📱 访问地址: http://$(curl -s ifconfig.me):8000"
echo ""
echo "📊 常用命令:"
echo "  查看状态: sudo systemctl status worldcup"
echo "  查看日志: sudo journalctl -u worldcup -f"
echo "  重启服务: sudo systemctl restart worldcup"
echo "  停止服务: sudo systemctl stop worldcup"
echo ""
